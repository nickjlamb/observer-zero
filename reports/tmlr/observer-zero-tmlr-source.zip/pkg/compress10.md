@@@ ## Limitations | -
## Limitations

All results sit within one agent loop, one memory design and one prompt family, so invariance
claims are invariant across what we varied and no further. Ten seeds per condition per arm give
wide intervals on binary outcomes; the headline 0-of-40 is robust in direction but its exact 95%
upper bound on runs is 8.8%, not zero. The institution null may be persona-scoped, the bulletin
being read overwhelmingly by the journalist. Agents know Kuhn and Bostrom from pretraining, so
Observer Zero does not test whether naive minds invent the simulation hypothesis. And no
provider exposes a sampling seed, so run-level variance includes sampling variance, which is
also part of the phenomenon.

On measurement: all judged metrics use an Anthropic judge over Anthropic and Perplexity agents,
triangulated with a lexicon tripwire and a manual claim audit, but inter-judge agreement with a
non-Anthropic judge remains future work, and exposure is *delivered*, not attended. The detector's ten-day baseline is an analyst choice, clean because the onset is day
12; recomputed at 6, 8, 10, 12 and 14 days — the last two deliberately contaminated by
post-onset observations — every gravity_shift run in every Study 2 arm is flagged at every
setting, and the contaminated windows *degrade* the statistic, confirming ten days is the
largest clean window, not a tuned one. In control worlds the detector flags 1–4 runs of
10 at mean |z| 1.5–1.8, so it is not a perfect instrument, and it remains an instrument we
specified rather than a ground truth. The detection criterion also counts self-error and
environmental attributions as anomaly mass, which inflates "detection" for chatty models, though
all arms are scored identically. Design confounds are set out in Appendix C, with the audit
trail.

@@@ ## Broader impact statement | -
## Broader impact statement

The results concern the reliability of LLM agents proposed for use as autonomous investigators, and two bear
directly on deployment risk. A monitoring system built from agents of this kind would collect
adequate evidence of a regime change and report a local instrument fault, so evaluations that
score data collection, or that score conclusions without measuring what evidence was available,
will certify such a system as working. And a channel that carries almost no traffic is not
thereby safe. We report a failure to draw a warranted conclusion rather than a capability that
could be misused, and the environment contains no real-world knowledge, so we see no dual-use
concern. The chief risk of misreading this work is over-generalisation: the results are bounded
by one world and the model versions in the manifests.

@@@ ## Reproducibility statement | -
## Reproducibility statement

Measurement noise is keyed by (world seed, instrument, trial index), so any society can be
re-run against an identical universe; prompts, personas, engine constants and model settings are
hashed into a manifest stamped into every run artifact; and the hypothesis judge is one frozen
model at temperature 0, held constant across both studies. The model code, the raw run artifacts
and derived artifacts sufficient to reproduce every number here are deposited publicly; the
deposit is withheld from this version for anonymity.
