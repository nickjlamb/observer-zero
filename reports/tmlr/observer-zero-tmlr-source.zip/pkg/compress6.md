@@@ ### How much evidence did the agents actually gather? | -
### How much evidence did the agents actually gather?

The first objection to everything that follows is that the shift may simply have been too small
to find. If so, declining to conclude *law change* would be correct Bayesian behaviour and the
ceiling would be a statement about the scenario rather than about the agents. Three independent
arguments close this off, and only two use the detector.

**The task is solvable without any detector at all.** Study 1's scripted mock society — arm B0,
which always replicates, always blindly, and applies textbook sequential statistics — diagnoses
gravity strictly in 10 of 10 gravity worlds on the any-agent criterion and stays quiet in 7 of
10 control worlds. The observation stream therefore contains sufficient information for a
specified scientific procedure to discriminate the conditions, established using no instrument a
sceptical reader would have to accept.

**The signal in the agents' own notebooks rose, and the conclusion did not follow.**

![Figure 2](figures/fig2-evidence-gradient.png)

**Figure 2.** Evidence rose; the conclusion did not follow. Signal available in the agents' own chosen measurements (upper panel) against the rate at which agents concluded a physical law had changed (lower panel), across nine conditions ordered by signal strength.

**Table 2 — L2 as-produced, gravity_shift worlds, ten-day baseline.** Mean maximum pendulum |z| over runs, and runs in which the detector flagged the change.

| Condition | *n* | mean \|z\| | flagged | law-change conclusions |
|---|---|---|---|---|
| Study 1 B1 haiku | 2 | 3.30 | 8/10 | 0 |
| Study 1 B2 sonnet | 2 | 3.88 | 7/10 | 0 |
| Study 1 B3b sonnet-nmp | 2 | 4.49 | 9/10 | 0 (one in a *control* world) |
| Study 1 B3a sonar | 2 | 5.00 | 10/10 | 0 |
| Study 2 arm A sonar | 2 | 5.77 | 10/10 | 0 of 20 agents |
| Study 2 arm B sonar | 8 | 7.28 | 10/10 | 1 of 80 agents |
| Study 2 arm C sonar | 8 | 7.09 | 2/2 | 0 of 16 agents |
| Study 2 arm D | 8 | 7.42 | 10/10 | 0 of 80 agents |
| Study 2 arm E | 8 | 7.52 | 10/10 | 0 of 80 agents |

Signal strength rises by a factor of 2.3 across the programme and detection rises from 7 of 10
runs to 10 of 10, while **the law-change conclusion rate does not move off the floor at any
point on that gradient.** This is stronger than sufficiency: a single sufficiency claim invites
the reply that the threshold might lie above z ≈ 7, whereas a monotone gradient with a flat
response shows no point on the observed range at which the behaviour changes.

**And their measurement policy was not the problem.** The shift was detectable in 42 of 42
Study 2 gravity_shift runs, typically from day 12 of 30, and remains so in 99–100% of draws when
downsampled to a two-agent budget, so this is not a benefit of scale. At *n* = 8 the L1 → L2 gap
is *negative* in every arm.

**Table 3 — the three-level detector benchmark.** A negative policy gap means the society's own measurement choices supported a stronger signal than the fixed reference schedule.

| Arm | L1 reference | L2 as-produced | policy gap | L2d at *n*=2 budget |
|---|---|---|---|---|
| A (*n*=2) | 6.33 | 5.77 | +0.56 | 100% of draws |
| B (*n*=8) | 6.33 | **7.28** | −0.95 | 99% |
| D (*n*=8) | 6.33 | **7.42** | −1.09 | 99% |
| E (*n*=8) | 6.33 | **7.52** | −1.19 | 100% |

The decomposition isolates the failure precisely: L1 → L2, measurement-policy quality, better
than reference; L2 → L3, interpretation quality, total. The diagnostic is not constructed to
convict the agents — run on Study 1's per-agent streams it estimates onset at median day 10.5 on
haiku's erratic schedules against day 12.0 on sonnet's more systematic ones, exonerating one arm
and convicting another. Its robustness to the baseline window and its false-alarm floor are
reported under limitations.

@@@ ### A serious alternative reading of the contamination result | -
### A serious alternative reading of the contamination result

The obvious interpretation is social: grounded agents deferred to a peer. Hu and Qu (2026) make
that harder to sustain without a control we do not have. Holding the asserted answer fixed and
deleting the explicit speaker, they find the no-source condition alone induces harmful revision
in 66.5% of initially correct items across six models and seven datasets, against 10.3% under a
plain re-ask, with the strongest expert-panel framing only 12.9 points above that speaker-free
floor. Revision should therefore be credited to a social effect only as an increment *above*
what bare asserted text already produces, and every claim in our societies arrives inside an
attributed letter from a named colleague. What survives is substantial: arm B is a control their
design does not have, since no assertion is present at all, so the D − B contrast is *assertion
present versus assertion absent*. That claims were incorporated, that none were challenged, and
that recipients cited the delivery event id are all unaffected; what is at risk is the further
inference that this reflects social deference specifically. The missing arm is now specified —
deliver identical claim content with the sender attribution stripped, and measure incorporation
against the attributed condition.

@@@ ### Where the ceiling does not come from | -
### Where the ceiling does not come from

Two studies make the two easiest explanations untenable: not insufficient evidence, since the
gradient is monotone and the negative policy gap rules out a data-collection artefact; and not
the explicit prompt prior, since removing the guardrail did not convert conservatism into
insight but into false alarms — a design finding in its own right for deployed systems, which
will inherit some version of that prior either explicitly or through training. What remains is a
shorter list, and we do not adjudicate between its items: epistemic conservatism shared across
contemporary models from training; the agent architecture and its evidence presentation; the
experimental framing; or interactions among these.
