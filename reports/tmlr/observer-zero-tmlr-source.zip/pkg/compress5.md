@@@ ### Contributions | -
### Contributions

**An instrumented environment and a frozen evaluation platform:** a deterministic world with
fictional physics, instrument classes designed for causal discrimination rather than mere
detection, power-analysed covert interventions, information-flow security enforced by type so
that no prompt-constructing code can receive ground truth, seeded batteries, versioned
manifests, a thirteen-class hypothesis taxonomy and a provenance-checked claim evaluator.

**A three-level decomposition that estimates what was knowable.** The non-LLM change-point detector
receives no privileged world information and carries a built-in negative control, one instrument
class being insensitive to the manipulated constant by construction. Comparing a fixed reference
schedule over every instrument (L1), the society's as-produced measurements (L2), a
budget-matched subsample (L2d) and the society's conclusions (L3) separates measurement-policy
quality from data quantity from interpretation quality. We offer this as a reusable evaluation
pattern, not only as an analysis of these runs.

**Interpretation failure measured against an evidence gradient** rather than against a single
sufficiency claim — which would invite the reply that the threshold may lie above the level
tested. A monotone gradient in available signal against a flat conclusion response locates the
failure in what was concluded rather than in what was available or gathered.

**Voluntary communication as a measured quantity, and what a catalysed channel carries:** a
zero-initiation baseline observed three independent times, then claim propagation with an origin
split and provenance checking, in which the channel reliably carries unsupported claims and
cascade depth never exceeds one.

@@@ ### What we do not claim | -
### What we do not claim

That LLM agents under-use evidence is established elsewhere and at larger scale (Ríos-García et
al., 2026); the contribution here is not the phenomenon but its location. We do not claim to
have identified the ceiling's cause, only to have made the two easiest explanations untenable;
nor a general property of mixed agent populations, the activation results resting on one
composition ratio and one model pairing; nor that errors amplify along agent chains, since
nothing here propagated far enough to amplify and the opposite result has been reported
(Jamshidi et al., 2026).

![Figure 1](figures/fig1-pipeline.png)

**Figure 1.** Where collective epistemic competence breaks down: the intended pipeline, and what Observer Zero finds at each link. The pipeline runs world → measurement → evidence → belief → communication → collective belief, and is intact from world to evidence, severed from evidence to belief, largely absent from belief to spontaneous communication, terminating at depth 1 from communication to network, and — the one place it works efficiently — open from communication to peer belief, for claims with no evidence behind them.

@@@ ### Cross-study synthesis | -
### Cross-study synthesis

Four things are true across both studies that neither establishes alone. **The evidence gradient
is monotone and the conclusion response is flat** — Table 3 spans nine conditions from |z| 3.30
to 7.52 while the law-change rate stays pinned at the floor, a shape that exists only because
the two studies share a world, a detector and a judge. **Zero spontaneous communication is
observed three independent times,** at two society sizes and with and without a public
institution. **The fabrication dissociation recurs in a different design**, measured as a rate
across whole societies in Study 1 and as a controlled substitution in a single persona slot in
Study 2, sharing no analysis path yet separating the same model families in the same direction.
And **back-dating replicates while unconditional commitment does not**: Study 1's early-dating
fractions of 0.79 to 0.85 become 0.872 pooled at *n* = 8, exactly as H4 predicted, while the
related behaviour Study 1 called invariant "across all tested model and prompt conditions"
(Lamb, 2026, p.9) attenuates from 0.838 to 0.341 across the same scale change. Reporting both
directions is the point: one comparison confirms a prior claim and the other narrows it.

One limitation applies to the synthesis rather than to either study. Study 1's B3a and Study 2's
arm A are both two-agent sonar societies on the same world seeds — literally the same universes
— yet their as-produced signal differs, 5.00 against 5.77. Since the worlds are identical that
gap is attributable entirely to what the agents chose to measure, and the prompt templates
changed between the studies, so **cross-study comparisons of as-produced signal confound
measurement policy with prompt version** and the gradient must not be described as a clean
manipulation.

@@@ ## Broader impact statement | -
## Broader impact statement

The results concern the reliability of LLM agents used as autonomous investigators. Two bear
directly on deployment risk. A monitoring system built from agents of this kind would collect
adequate evidence of a regime change and report a local instrument fault, so evaluations that
score data collection, or that score conclusions without measuring what evidence was available,
will certify such a system as working. And a channel that carries almost no traffic is not
thereby safe: in societies that never formed a network at all, eighteen of twenty unsupported
claims were incorporated into peers' beliefs and none were challenged. We report a failure to
draw a warranted conclusion rather than a capability that could be misused, and the environment
contains no real-world knowledge, so we see no dual-use concern in the artifacts. The chief risk
of misreading this work is over-generalisation: the results are bounded by one world, one
composition ratio and the model versions named in the manifests.
