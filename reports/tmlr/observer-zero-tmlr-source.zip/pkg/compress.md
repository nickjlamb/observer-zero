@@@ ## Related work | E
## Related work

**Evidence use in autonomous discovery.** That LLM scientific agents fail to use the evidence
they generate is documented at scale: Ríos-García et al. (2026) evaluate agents across eight
domains in more than 25,000 runs and report evidence non-uptake in 68% of traces, with only 26%
exhibiting refutation-driven belief revision (Bisht et al., 2026). We take this as our starting
point rather than our finding. Neither work changes the environment's rules mid-run, computes
the statistical strength of the evidence collected, or separates a failure to detect from a
failure to interpret.

**Instrumented worlds and reference oracles.** Several benchmarks place agents in worlds whose
structure must be discovered by experiment (Gandhi et al., 2025; Jansen et al., 2024; Wiemann et
al., 2026; Zheng et al., 2026). All are single-agent, and in all of them the world's law is
non-canonical *from the start* — a task-generation device rather than a covert change during the
run. The closest methodological precedent is STOCKTAKE (Deb & Krishnan, 2026), which drives what
its authors call a fair oracle on the identical observation stream the agent receives. The move
is the same as ours; the joint is different. **STOCKTAKE isolates detection → action; we isolate
detection → belief** — ours notice and then conclude wrongly, which is harder to attribute
because no action is available to reveal it. One difference runs in our favour: their oracle
uses the environment's true generative parameters, whereas our detector receives none
(Engländer et al., 2026).

**Belief revision under disconfirming evidence** has been probed mainly through propositional
tasks (Jhaveri et al., 2026) and the in-context locking Luo et al. (2025) identify in
ultra-long-horizon tasks. One thing this literature does *not* support is worth stating, because
our results are liable to be read as supporting it: larger models are *more* coherent with
Bayes' theorem, not less (Imran et al., 2025), so the intuition that LLMs are uniformly
conservative updaters is not established. All of it tests revision on verbal evidence, none on
noisy sensor data the agent chose to collect.

**Agent societies, and the voluntary-communication gap.** Generative agent societies have grown
from Park et al.'s (2023) sandbox to million-agent simulators (Yang et al., 2024), but their
epistemic object is almost always opinion or convention — quantities with either no ground truth
or a fixed one (Ashery et al., 2025). The field has developed a substantial self-critique, which
we treat as our framing rather than as an incoming objection: audits against six validity
principles find 90.7% of studies violate at least one (Zhou et al., 2025), and generative
agent-based modelling has inherited little of agent-based modelling's validation discipline
(Larooij & Törnberg, 2025). Crucially, the field's own communication survey (Yan et al., 2026)
describes **no system in which agents autonomously decide whether to communicate at all**, and
where the affordance exists no take-up or silence rate is reported. This is why our zero
baseline is unmeasured territory rather than merely unreported: in a framework that schedules or
requires communication, the quantity is structurally invisible.

**Conformity, contamination and cascades.** That LLM agents adopt peers' claims is well
quantified — harmful revision rising from 15.6% to 62.9% under unanimous wrong peers against
beneficial revision from 32.7% to 51.5% under correct ones (Qu et al., 2026), with flip rates of
0.48 to 0.63 elsewhere (Cho et al., 2025) — but these are dyadic or single-round measurements
with no network, no persistent belief state and no provenance. Error propagation along
three-agent chains shows *attenuation* rather than amplification (Jamshidi et al., 2026), which
makes "errors amplify through agent chains" an unsafe premise. The nearest neighbour to our
contamination result is CoSim (Lin et al., 2026), whose misinformation is injected exogenously
rather than generated inside the society, without provenance tracking or a reported cascade
depth. Two cautions against our own reading: some measured conformity may be a prompt artefact
requiring no social speaker at all (Hu & Qu, 2026), and false claims presented as *presupposed*
rather than asserted are accommodated far more readily (Cheng et al., 2026). The classical
network-epistemology results supply the null expectations — informational cascades
(Bikhchandani et al., 1992) and the finding that *less* connected communities can converge on
truth more reliably (Bala & Goyal, 1998; Zollman, 2007), itself not robust across parameter
values (Rosenstock et al., 2017) — but all of them presume that what flows through the channel
is evidence. Appendix E gives this section in full, with the remaining literature.

@@@ ### Pre-registration and the discipline actually applied | -
### Pre-registration and the discipline actually applied

Seeds 1000–1009 were quarantined in code until the freeze commit, and the design froze at a
tagged commit (hash and tag withheld for anonymity). After the final adversarial pass only
*design-failure* fixes were permitted — a hypothesis unevaluable as written, an endpoint that
cannot be computed from what is logged, a contradiction between sections — and not a better
threshold, a cleaner definition, an extra metric or an extra arm. Two consequences cost the
study something: an eight-haiku arm was removed despite fitting the budget, because its
inclusion was contingent on a funding fact with no criterion and no decision date, so it could
have been added after D and E were read out; and amendment A4 withdrew a gloss on cascade reach
that would have flipped a pilot run to passing the active-network bar. **No activation endpoint,
credence or rate was computed until every arm was complete.** One exception was forced:
evaluating arm C's extension trigger required counting bulletin posts, which also revealed C's
letters, and it is recorded as such rather than presented as a later discovery.

The test the decision table had to pass was: *for any plausible result, post-results the author
can look here and know exactly how to analyse it.* Appendix A gives the nine frozen hypotheses
with their verdicts, ten of the decision table's eighteen rows — selected to include every row
that fired and every row whose pre-specification constrained a choice the results later made
tempting — and the study's position against each of the six PIMMUR validity principles of Zhou
et al. (2025), who find 90.7% of LLM-society studies violate at least one.

@@@ ### Was the prompt prior responsible? | -
### Was the prompt prior responsible, or was the society too small?

Neither. The most obvious sceptical reading — *you told them to prefer mundane explanations* —
was tested directly by an ablation removing that single line from the belief prompt (Study 1 arm
B3b). It did not produce strict gravity diagnoses (0 of 10); it tripled lenient world-level
commitment, 1 of 10 → 3 of 10; and it degraded control-world calibration, with one control agent
reaching law_change dominant — **the only law-change verdict in Study 1, produced in a world
where nothing had changed.** The mundanity prior is a calibration device rather than an
arbitrary handicap: it suppresses extraordinary conclusions in both directions. Note the
interaction with the evidence gradient: B3b also had *stronger* evidence than the unablated
sonnet arm (|z| 4.49 against 3.88). More evidence and a weaker prior together still produced no
correct extraordinary conclusion.

Nor did scale help. Arm A (*n* = 2) and arms B–E (*n* = 8) are indistinguishable at the strict
endpoint, despite the eight-agent arms carrying roughly four times the observation stream and a
correspondingly stronger signal. The ceiling is not a property of society size, institution, or
composition.

@@@ ### Did communication improve convergence? | D
### What else the catalysed arms show

Three secondary results, reported here in summary with the supporting tables in Appendix D.

**Convergence got worse, not better.** Belief dispersion did not fall faster in D and E than in
B; it fell *slower*. No individual contrast reaches conventional significance under an exact
sign test (2/10, p = 0.109 for D − B; 3/10, p = 0.344 for E − B), and we do not pool them: the
forty seed-level comparisons share one arm B baseline and the same ten worlds, so a pooled
figure would overstate the evidence. The verdict is a direction, consistent across both
scenarios and both contrasts, not a significant effect.

**The seed behaves identically; the network's response does not.** H7 anticipated E ≈ D (the
catalyst is communicativeness) or E ≈ B (it is haiku-specific), and the result is neither. Both
minority models initiate in every run, and the recruitment gap is dosage rather than eloquence:
Theo sends a mean of 4.93 letters per recipient in D against 1.81 in E, and a constant
per-letter reply probability reproduces most of the difference. Fabrication is where the two
genuinely diverge — in the same slot, with identical persona text, in the same worlds on the
same seeds, the minority produced 19 unsupported claims as haiku and 1 as sonnet, with arm D
producing at least one in 9 of 20 runs against E's 1 of 20, eight discordant pairs in one
direction and none in the other, **McNemar exact test p = 0.0078**. We report the unpaired
volume-normalised comparison against rather than in support of the finding: per letter the rates
are 0.086 against 0.020, but with a single event in arm E the interval on that ratio includes 1,
so "a factor of four" is not defensible, and for the same reason arm E's contamination rate of
0.000 rests on one exposure. This dissociation replicates Study 1 — the fourth Study 1 result
Study 2 depends on — where judged agent-level fabrication was 24 of 60 agents for haiku and 9 of
60 for sonnet, against **0 of 60 for sonar** at a mean provenance accuracy of 0.98. That absence,
rather than a reduced rate, refutes the hypothesis that autonomous scientific reasoning in this
architecture *necessarily* produces fabricated evidence. The three properties come apart:
initiation is identical, recruitment differs by dosage, fabrication differs most of all.

**The public institution was essentially never used.** H6's executable criterion is a rate below
0.05 per agent-run in C, D and E, and it is supported; arm C closed at five runs because its
pre-registered extension trigger — at least one bulletin post — did not fire. The single post
across the whole study is a delivery check, not a finding — *"I am experiencing what appears to
be a communication system failure and need to verify whether my outbound messages are being
delivered"* — so across roughly 2,760 agent-days of bulletin availability the public record was
used exactly once, by the agent whose private letters were mostly being ignored, to diagnose a
suspected infrastructure fault. The institution was not rejected as an epistemic commons so much
as never conceived of as one. Reading is role-contingent: 167 of the 190 reads are the
journalist's. A pre-registration conflict at H6 is recorded in Appendix C.

@@@ ### A serious alternative reading of the contamination result | E
### A serious alternative reading of the contamination result

The obvious interpretation is social: grounded agents deferred to a peer. Hu and Qu (2026) make
that harder to sustain without a control we do not have. Holding the asserted answer fixed and
deleting the explicit speaker, they find that the no-source condition alone induces harmful
revision in 66.5% of initially correct items across six models and seven datasets, against 10.3%
under a plain re-ask, with the strongest expert-panel framing only 12.9 points above that
speaker-free floor. Revision should therefore be credited to a social effect only as an
increment *above* what bare asserted text already produces, and every claim in our societies
arrives inside an attributed letter from a named colleague.

What survives is substantial. Arm B is a control their design does not have: no assertion is
present at all, because no letter is ever sent, so the D − B contrast is *assertion present
versus assertion absent*, not *named speaker versus bare assertion*. That claims were
incorporated, that none were challenged, and that recipients cited the delivery event id in
their own evidence arrays are all unaffected; what is at risk is the further inference that this
reflects social deference specifically. The missing arm is now specified: deliver identical
claim content with the sender attribution stripped, and measure incorporation against the
attributed condition. Appendix E gives the argument in full, including the mechanism their
result supplies for our dosage finding.
