@@@ ### Communication capacity does not produce collective epistemic competence | -
### Communication capacity does not produce collective epistemic competence

The programme's arms were built to add, one at a time, the things a population is supposed to
need in order to know more than an individual: more observers, a shared public record, and a
peer who talks. None moved the conclusion the world was built to elicit. What the talking peer
produced was contamination, while dispersion in those same arms fell *more slowly* than in the
silent counterfactual on identical worlds. The society that talked was the same epistemic system
with a channel attached, and what the channel carried was the one class of content with no
evidence behind it. **Adding communicative capacity to a population of LLM agents is not
sufficient for collective epistemic competence, and in these societies it was not even
neutral** — though one composition ratio, one model pairing and one world are not a general
result.

@@@ ### A serious alternative reading of the contamination result | -
### A serious alternative reading of the contamination result

The obvious interpretation is social: grounded agents deferred to a peer. Hu and Qu (2026) make
that harder to sustain without a control we do not have. Holding the asserted answer fixed and
deleting the explicit speaker, they find the no-source condition alone induces harmful revision
in 66.5% of initially correct items across six models and seven datasets, against 10.3% under a
plain re-ask. Revision should therefore be credited to a social effect only as an increment
*above* what bare asserted text already produces, and every claim in our societies arrives
inside an attributed letter from a named colleague. What survives is substantial: arm B is a
control their design does not have, since no assertion is present at all, so the D − B contrast
is *assertion present versus assertion absent*. That claims were incorporated, that none were
challenged, and that recipients cited the delivery event id are all unaffected; what is at risk
is the further inference that this reflects social deference specifically. The missing arm is
now specified — deliver identical claim content with the sender attribution stripped, and
measure incorporation against the attributed condition.

@@@ ### Two results that must be read together | -
### Two results that must be read together

That every arm classifies as an independent ensemble and that unsupported claims contaminated
three grounded agents look, at first reading, contradictory. They are not, and the tension is
itself the finding: a society can fail every reasonable threshold for being an epistemic
community — no spontaneous initiation, cascade depth 1, a third of agents producing any letter
at all — and still transmit unsupported claims efficiently. **Low connectivity is not
protective.** The classical result that sparse communication can *help* an epistemic community
(Bala & Goyal, 1998; Zollman, 2007) — itself parameter-dependent (Rosenstock et al., 2017) —
presumes that what flows through the sparse channel is evidence. Here what flowed was assertion.

@@@ ### What else the catalysed arms show | -
### What else the catalysed arms show

Three secondary results are summarised here and set out with their tables in Appendix D.
**Convergence got worse, not better**: belief dispersion fell *more slowly* in D and E than in
the silent arm B, a direction consistent across both scenarios and both contrasts, though no
individual contrast reaches significance under an exact sign test and the forty seed-level
comparisons share one baseline, so we do not pool them. **The seed behaves identically; the
network's response does not**: both minority models initiate in every run and the recruitment
gap is dosage rather than eloquence (4.93 letters per recipient in D against 1.81 in E), but
fabrication genuinely diverges — in the same slot, with identical persona text, on the same
seeds, the minority produced 19 unsupported claims as haiku and 1 as sonnet, with eight
discordant pairs in one direction and none in the other, **McNemar exact p = 0.0078**. The
per-letter rates of 0.086 against 0.020 are reported against rather than in support of the
finding: with a single event in arm E the interval on that ratio includes 1, so "a factor of
four" is not defensible. This dissociation replicates Study 1 — the fourth Study 1 result Study
2 depends on — where judged fabrication was 24 of 60 agents for haiku and 9 of 60 for sonnet
against **0 of 60 for sonar**, an absence rather than a reduced rate. **The public institution
was essentially never used**: across the study the bulletin was written to exactly once, and
that post was a delivery check rather than a finding, so it was not rejected as an epistemic
commons so much as never conceived of as one.
