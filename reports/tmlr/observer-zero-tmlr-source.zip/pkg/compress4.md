@@@ ### What else the catalysed arms show | -
### What else the catalysed arms show

Three secondary results are summarised here and set out with their tables in Appendix D.
**Convergence got worse, not better**: belief dispersion fell *more slowly* in D and E than in
the silent arm B, a direction consistent across both scenarios and both contrasts, though no
individual contrast reaches significance under an exact sign test and the forty seed-level
comparisons share one baseline, so we do not pool them. **The seed behaves identically; the
network's response does not**: both minority models initiate in every run, the recruitment gap
is dosage rather than eloquence (4.93 letters per recipient in D against 1.81 in E), but
fabrication genuinely diverges — in the same slot, with identical persona text, on the same
seeds, the minority produced 19 unsupported claims as haiku and 1 as sonnet, with eight
discordant pairs in one direction and none in the other, **McNemar exact p = 0.0078**. This
dissociation replicates Study 1 — the fourth Study 1 result Study 2 depends on — where judged
fabrication was 24 of 60 agents for haiku and 9 of 60 for sonnet against **0 of 60 for sonar**,
an absence rather than a reduced rate, which refutes the hypothesis that autonomous scientific
reasoning in this architecture *necessarily* produces fabricated evidence. **The public
institution was essentially never used**: across roughly 2,760 agent-days of bulletin
availability the public record was written to exactly once, and that post was a delivery check
rather than a finding, so the institution was not rejected as an epistemic commons so much as
never conceived of as one.

@@@ ## Limitations | -
## Limitations

All results sit within one agent loop, one memory design and one prompt family, so invariance
claims are invariant across what we varied and no further. Ten seeds per condition per arm give
wide intervals on binary outcomes; the headline 0-of-40 is robust in direction but its exact 95%
upper bound on runs is 8.8%, not zero. The institution null may be persona-scoped, the bulletin
being read overwhelmingly by the journalist. Agents know Kuhn and Bostrom from pretraining, so
Observer Zero does not test whether naive minds invent the simulation hypothesis. And no
provider exposes a sampling seed, so run-level variance includes sampling variance, which is
also part of the phenomenon.

On measurement: all judged metrics use an Anthropic judge over Anthropic and Perplexity agents,
triangulated with a model-free lexicon tripwire and a manual claim audit, but full inter-judge
agreement with a non-Anthropic judge remains future work. Exposure is *delivered*, not attended.
The detector's ten-day baseline is an analyst choice, clean because the onset is day 12;
recomputed at 6, 8, 10, 12 and 14 days — the last two deliberately contaminated by post-onset
observations — every gravity_shift run in every Study 2 arm is flagged at every setting, and the
contaminated windows *degrade* the statistic, confirming ten days is the largest clean window
rather than a tuned one. In control worlds the detector flags 1–4 runs of 10 at mean |z|
1.5–1.8, so it is not a perfect instrument, though the separation is never marginal. And the
detection criterion counts self-error and environmental attributions as anomaly mass, which
inflates "detection" for chatty models, though all arms are scored identically.

Design confounds are set out in Appendix C, together with the ways the pre-registration was and
was not honoured in implementation, what the run artifacts contain, three defects found at
analysis time and how each was resolved, and two errata in previously released documents.

@@@ ### Do homogeneous grounded agents spontaneously communicate? | -
### Do homogeneous grounded agents spontaneously communicate?

No, and this is the most heavily replicated result in the programme. It is also the third Study
1 result Study 2 depends on: arm B's zero is only interpretable because Study 1 established that
this model produces no letters in a two-agent society.

**Table 6 — voluntary communication in homogeneous grounded societies.**

| Source | Design | Runs | Agent-days | Letters | Posts |
|---|---|---|---|---|---|
| Study 1 B3a | 2 × sonar, letters | 30 | 1,800 | **0** | n/a |
| Pilot P1-A | 2 × sonar, letters | 3 | 180 | **0** | n/a |
| Pilot P1-A′ | 2 × sonar, bulletin | 3 | 180 | **0** | **0** |
| Pilot P1-C | 8 × sonar, bulletin | 3 | 720 | **0** | **0** |
| Study 2 arm B | 8 × sonar, letters | 20 | 4,800 | **0** | n/a |

Arm B's rates are not merely near zero but exactly zero: no letter was sent in 20 runs and 160
agent-runs. Summing the homogeneous grounded conditions gives **7,680 agent-days of voluntary
communication opportunity and zero voluntary communications.** Agent-days measure exposure, not
independent trials, so the interval is attached to the agent-run, the unit the endpoint is
defined on: zero initiations in 256 agent-runs, exact 95% CI [0, 1.43%]. This is not
deliberation ending in refusal — of 180 action reasons recorded in the pilot's two-agent
bulletin condition, exactly one even names the bulletin or the colleague, and that one is a
false-positive match.

Scope, precisely. Spontaneous communication was absent in every pre-registered letter condition,
and across the 320 agent-runs of the two mixed-composition arms no grounded agent ever
initiated. One exception is reported rather than smoothed: in arm C's `gravity_shift-seed1001` a
pure-sonar dyad forms, one spontaneous initiator in that arm's 40 agent-runs, with all eight
agents verified `sonar-pro` in the manifest before this was believed. One available reading is
that a chatty peer *suppresses* grounded initiation rather than enabling it; untested here.
