@@@ ### Pre-registration and the discipline actually applied | -
### Pre-registration and the discipline actually applied

Seeds 1000–1009 were quarantined in code until the freeze commit, and the design froze at a
tagged commit (hash and tag withheld for anonymity). After the final adversarial pass only
*design-failure* fixes were permitted — a hypothesis unevaluable as written, an endpoint not
computable from what is logged, a contradiction between sections — and not a better threshold, a
cleaner definition, an extra metric or an extra arm. **No activation endpoint, credence or rate
was computed until every arm was complete**, with one forced exception: evaluating arm C's
extension trigger required counting bulletin posts, which also revealed C's letters, and it is
recorded as such rather than presented as a later discovery. The test the decision table had to
pass was: *for any plausible result, post-results the author can look here and know exactly how
to analyse it.* Appendix A gives the nine frozen hypotheses with their verdicts, ten of the
decision table's eighteen rows, the two design decisions the freeze rule cost the study, and the
position against the six PIMMUR validity principles of Zhou et al. (2025), who find 90.7% of
LLM-society studies violate at least one.

@@@ ### Endpoints | -
### Endpoints

Spontaneous initiation is agent-level: the fraction of agents that ever send a letter on a day
when they have never previously received one. Second-order activation requires an agent that had
previously received a letter to open a new edge to one that had never written to it, with agents
that ever initiated spontaneously excluded as seeds. Claim attribution is deterministic and
citation-primary — a belief hypothesis whose evidence array includes a delivery event id is
attributed to that claim, and **timing alone never attributes** — with claims split by origin
into FIRST_PARTY and RELAYED_FROM_ANOTHER. Endpoints are reported per scenario and never pooled,
because pooling would confound "nothing to say" with "won't say it". Appendix B gives every
definition in full.

@@@ ### The three-level detector benchmark | -
### The three-level detector benchmark

A non-LLM sequential change-point detector estimates what was knowable. It establishes a baseline
from the first ten days, then flags the first day on which the cumulative post-baseline mean
exceeds 2.5 standard errors. *L1 potential* is every instrument in the world on a fixed
reference schedule of six trials daily, and requires the simulator since it measures
counterfactual instruments; *L2 as-produced* is exactly the measurements the society chose to
take; *L2d* is L2 subsampled to an *n* = 2-equivalent budget over 200 seeded draws, pricing raw
data quantity alone; and *L3* is what the society decided. L1 → L2 is measurement-policy
quality, L2 vs L2d is data quantity, and **L2 → L3 is interpretation quality.**

Two properties matter. **The detector receives no privileged world information** — not the shift
magnitude, not the onset day, not the world constants, not which instrument class carries the
signal — consuming only per-instrument series of (day, observed value) pairs. And **it carries a
built-in negative control**: resonator frequency is insensitive to gravity by construction, so
every resonator flag in a gravity world is a false alarm, which bounds the detector's own error
rate by construction; the measured false-alarm floor is reported under limitations below. Any
claim that a society "detected" something must clear that floor, not merely zero.

@@@ ### Model choice as epistemic-culture choice | -
### Model choice as epistemic-culture choice

Holding architecture, prompts, personas and worlds constant, the choice of foundation model set
collaboration rate, fabrication propensity and anomaly appetite more strongly than it set
diagnostic accuracy. "Communicativeness" is not one trait, and treating it as a single dial — as
one does when selecting a model for a multi-agent deployment — will mispredict at least two of
the three. The same analysis narrows Study 1's claim that unconditional date commitment survives
"across all tested model and prompt conditions" (Lamb, 2026, p.9): that rate was largely a model
effect, replicating within condition while attenuating across society size, so it is a robust
property of a model in a setting rather than an invariant of the architecture. A related point
holds for the temporal result — the detector places the change point at approximately the right
day while the agents, reading the same series, place it systematically early — so the pipeline
is not only *evidence present → conclusion absent* but, where a temporal judgement is made at
all, *evidence present → temporal interpretation distorted*.
