#!/usr/bin/env python3
"""Markdown -> TMLR LaTeX."""
import re, subprocess, pathlib

ROOT = pathlib.Path("/home/claude/tmlr")
md = (ROOT / "observer-zero-tmlr.md").read_text()

# ---- title & abstract ---------------------------------------------------------
title = re.search(r"^# (.+)$", md, re.M).group(1)
abst = re.search(r"^## Abstract\n\n(.*?)\n\n## Introduction", md, re.S | re.M).group(1)
md = md[md.index("## Introduction"):]

# ---- figures: image + following bold caption -> raw LaTeX figure --------------
md = re.sub(r"(?<!\n)(!\[Figure)", r"\n\n\1", md)  # split the inline fig2 image out

def figure(m):
    path, n, cap = m.group(2), m.group(3), m.group(4)
    cap = " ".join(cap.split())
    return (
        "```{=latex}\n\\begin{figure}[t]\n\\begin{center}\n"
        f"\\includegraphics[width=0.95\\linewidth]{{{path}}}\n"
        f"\\end{{center}}\n\\caption{{{cap}}}\n\\label{{fig:{n}}}\n\\end{{figure}}\n```\n"
    )

md = re.sub(
    r"!\[Figure (\d)\]\(([^)]+)\)\s*\n\n\*\*Figure (\d)\.\*\* ((?:.+\n)+?)\n",
    figure, md)

# ---- tables: bold caption line above a pipe table -> pandoc caption below -----
def table(m):
    cap, tbl = m.group(1), m.group(2)
    cap = " ".join(cap.split())
    cap = re.sub(r"^\*\*Table \d+ — ", "**", cap)
    cap = re.sub(r"^\*\*Table \d+\*\*, ", "**", cap)
    cap = cap.replace("****", "").strip()
    if cap.startswith("**") and "**" not in cap[2:]:
        cap = cap[2:]
    rows = tbl.rstrip("\n").split("\n")
    hdr, sep = rows[0], rows[1]
    ncol = len(sep.split("|")) - 2
    widths = [0] * ncol
    for r in rows[:1] + rows[2:]:
        cells = r.split("|")[1:-1]
        for j, c in enumerate(cells[:ncol]):
            widths[j] = max(widths[j], len(c.strip()))
    total = sum(widths) or 1
    dashes = ["-" * max(3, round(w / total * 110)) for w in widths]
    rows[1] = "|" + "|".join(dashes) + "|"
    return "\n".join(rows) + "\n\n: " + cap + "\n\n"

md = re.sub(r"(?m)^(\*\*Table \d+[^\n]*)\n\n((?:\|[^\n]*\n)+)", table, md)

# ---- headings: ## -> section, ### -> subsection -------------------------------
frag = subprocess.run(
    ["pandoc", "-f", "markdown+raw_attribute", "-t", "latex",
     "--shift-heading-level-by=-1", "--wrap=preserve"],
    input=md, capture_output=True, text=True, check=True).stdout

abst_tex = subprocess.run(
    ["pandoc", "-f", "markdown", "-t", "latex", "--wrap=preserve"],
    input=abst, capture_output=True, text=True, check=True).stdout.strip()

# references section: hanging indent, no numbering
frag = frag.replace("\\section{References}", "\\section*{References}\n\\begingroup\n"
                    "\\setlength{\\parindent}{-0.25in}\\setlength{\\leftskip}{0.25in}\n"
                    "\\small")
frag = frag.rstrip() + "\n\\endgroup\n"
frag = frag.replace("\\section{Broader impact statement}", "\\section*{Broader Impact Statement}")
frag = frag.replace("\\section{Reproducibility statement}", "\\section*{Reproducibility Statement}")

preamble = r"""\documentclass[10pt]{article}
\usepackage{tmlr}
\usepackage{hyperref}
\usepackage{url}
\usepackage{graphicx}
\usepackage{longtable,booktabs,array}
\usepackage{etoolbox}
\usepackage{amsmath,amssymb}
\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage{calc}
\usepackage{textcomp}
\DeclareUnicodeCharacter{2212}{\ensuremath{-}}
\DeclareUnicodeCharacter{2192}{\ensuremath{\rightarrow}}
\DeclareUnicodeCharacter{2194}{\ensuremath{\leftrightarrow}}
\DeclareUnicodeCharacter{2248}{\ensuremath{\approx}}
\DeclareUnicodeCharacter{2265}{\ensuremath{\geq}}
\DeclareUnicodeCharacter{2264}{\ensuremath{\leq}}
\DeclareUnicodeCharacter{221A}{\ensuremath{\sqrt{\,}}}
\DeclareUnicodeCharacter{03C0}{\ensuremath{\pi}}
\DeclareUnicodeCharacter{03C3}{\ensuremath{\sigma}}
\DeclareUnicodeCharacter{2032}{\ensuremath{'}}
\DeclareUnicodeCharacter{2070}{\ensuremath{^{0}}}
\DeclareUnicodeCharacter{2074}{\ensuremath{^{4}}}
\DeclareUnicodeCharacter{207B}{\ensuremath{^{-}}}
\AtBeginEnvironment{longtable}{\footnotesize}
\providecommand{\tightlist}{\setlength{\itemsep}{0pt}\setlength{\parskip}{0pt}}
\setlength{\LTcapwidth}{\linewidth}
\setlength{\emergencystretch}{3em}
\hypersetup{colorlinks=true,linkcolor=black,citecolor=black,urlcolor=blue}

\title{TITLE}
\author{}

\def\month{MM}
\def\year{YYYY}
\def\openreview{\url{https://openreview.net/forum?id=XXXX}}

\begin{document}
\maketitle

\begin{abstract}
ABSTRACT
\end{abstract}

BODY

\end{document}
"""
title_tex = (title.replace(": ", ": \\\\ ", 1)
             .replace(" in LLM Agent", " \\\\ in LLM Agent"))  # avoid hyphenating the title
tex = (preamble.replace("TITLE", title_tex)
       .replace("ABSTRACT", abst_tex)
       .replace("BODY", frag))
(ROOT / "main.tex").write_text(tex)
print("ok", len(tex))
