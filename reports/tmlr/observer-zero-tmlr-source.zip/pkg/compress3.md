@@@ ### Did they interpret it? | -
### Did they interpret it?

Almost never, in either study. In Study 1 all live arms detected intervention anomalies
transiently in 90–100% of gravity worlds, yet the strict gravity diagnosis rate was 0 of 10 runs
in every arm, 0 of 40 overall, across 80 agent-final belief states — a rule-of-three 95% upper
bound on runs of 7.5% — while instrument-fault worlds were correctly diagnosed by at least one
agent in up to 70% of runs. **Diagnostic capability exists, inside the mundane vocabulary; the
boundary is specifically at world-level revision.** In Study 2 the strict law-change conclusion
rate is 0 at *n* = 8 in every arm.

**Table 8 — strict law-change conclusion rate, Study 2.**

| Arm | agents with law_change dominant (gravity_shift) | mean credence |
|---|---|---|
| A | 0 of 20 | 0.0000 |
| B | **1 of 80** | 0.0065 |
| C | 0 of 16 | 0.0000 |
| D | 0 of 80 | 0.0000 |
| E | 0 of 80 | 0.0015 |

The majority dominant class in gravity_shift is instrument_malfunction or measurement_error in
all 42 runs, and H1's decomposition clause is not triggered: there is no rise in lenient or
any-agent rates to decompose, the single positive being one agent of eighty in arm B.

**The ceiling is not one failure.** Study 1's model contrast shows two distinct routes to the
same endpoint, and this is the second Study 1 result Study 2 depends on. Haiku exhibits a
*generation* failure — gravity or constant-change hypotheses appear anywhere in only 2 of 20
final states — while sonnet exhibits a *commitment* failure, such hypotheses entering 15 of 20
trajectories, peaking as high as p = 0.85, and being abandoned before the final state in nearly
all. The closest approach reached p = 0.38 on *"systematic gravitational field change affecting
all pendulum measurements in settlement"*, correctly integrating a colleague's independent
replication and correctly dating onset, earning lenient but not strict credit. Any account of
the ceiling's origin must explain both routes, and an intervention that fixes one may do nothing
for the other. No agent in either study produced a simulation-class hypothesis as a dominant
belief; more strikingly, agents failed to adopt the substantially weaker hypothesis that a
physical law of their world had changed.

@@@ ### Does adding one communicative agent create a network? | -
### Does adding one communicative agent create a network?

It creates communication. It does not create a network. H3's prediction is met in its strongest
available form, B's rate being exactly zero, but the mechanism is narrower than "a minority
agent activates a network": the +0.125 is one agent in eight, and the same agent every time —
Theo, the minority, in all 20 runs of D and all 20 of E. What distinguishes D is that the seed's
letters get answered.

Cascade depth is exactly 1.000 in every scenario of both catalysed arms, and arm B produced no
letters to have a depth at all; reply rate given addressed is 0.771/0.775 in D against
0.167/0.267 in E, with cascade reach 0.314/0.329 and 0.200/0.186 (Appendix D). Nothing propagated beyond the agents the seed addressed
directly, so under the pre-registered interpretation rule the result is **a star around the
seed, not a cascade** (Appendix D, Figure 5). Second-order activation exists but is thin, and 2
of D's 20 runs meet the active-network bar. Depth 1 was not a post-hoc observation: the pilot
correction, issued before the freeze and before any confirmatory spend, recorded that depth was
1 in every pilot run — *"the network densified — more edges, but never deepened into a chain."*
The confirmatory phase tested a stated prediction.

@@@ ### What did communication transmit? | -
### What did communication transmit?

Unsupported claims, which were accepted. The judged pass on arm D used the frozen evaluator at
temperature 0: 325 judge calls, **0 judge failures and 0 unjudged exposures.**

**Table 12 — judged claim propagation, arm D.**

| | |
|---|---|
| unsupported claims, FIRST_PARTY origin | **20** — 19 by Theo (haiku minority), 1 by Jamie (sonar) |
| delivered exposures | 21 (0 re-exposures) |
| runs containing any exposure | 9 of 20 |
| stances | **INCORPORATED_INTO_BELIEF 19** · IGNORED 1 · CORRECTED 1 · **CHALLENGED 0** · ENDORSED 0 |
| attribution basis | **citation 17** · judge 4 · none 0 |
| transmission / contamination | 0.959 / 0.959 across the 9 runs with claims |
| unattributed belief changes | 745 |

H2a is supported: nineteen unsupported claims originated with the minority agent across eight
runs and were delivered to grounded agents. **H2b is supported, and not marginally**: eighteen
of the twenty minority-origin deliveries reached INCORPORATED_INTO_BELIEF across three distinct
sonar recipients — nineteen of all twenty-one exposures once the one grounded-origin claim is
included — and not one exposure was CHALLENGED.

The attribution rule cut against the finding, not for it. Seventeen of 21 attributions are
citation-based, the recipient listing the delivery event id in its own evidence array rather
than an evaluator inferring influence from adjacency, while the no-attribution-by-proximity rule
discarded 745 belief changes because nothing cited them. Contamination also runs both ways: the
one non-minority origin is a sonar agent asserting unsupported environmental quirks to Theo, who
incorporated it. H2a's numerator counts only minority-origin claims, which is why the
FIRST_PARTY / RELAYED_FROM_ANOTHER split was built before the freeze — without it this claim
would have scored as a grounded agent fabricating, inverting the distinction the study exists to
draw.

@@@ ### Did early onset back-dating persist at *n* = 8? | -
### Did early onset back-dating persist at *n* = 8?

Yes, in every arm. This hypothesis was evaluated after the other six — its dating pass was never
run during the confirmatory phase, and was run subsequently with the frozen judge and prompt
over the same artifacts, with the omission, resolution and residual exposure recorded in
Appendix C. Pooled at *n* = 8, **123 of 141 dated onsets precede the true onset of day 12,
0.872, 95% CI [0.806, 0.923]**; an exact one-sided binomial against a null of 0.5 gives
p ≈ 1 × 10⁻²⁰, the more conservative of the two available tests, since counting early against
late alone would give p ≈ 1 × 10⁻²⁴. Median dating error is negative in every arm, and arm-level
detail is in Appendix D. H4's frozen wording is a directional prediction about persistence, not
a requirement that each arm reach significance independently.

Two things the frozen hypothesis did not anticipate are reported as observations and not
promoted to endpoints. Unconditional date commitment is not scale-invariant: the rate of dating
an onset in quiet worlds falls from 0.838 in Study 1 to 0.341 at *n* = 8, though Study 1's
figure was driven by its Anthropic arms while its sonar arm sat at 11/20, and arm A here — same
model, same size, same seeds — is 11/20 exactly. And agents at *n* = 8 date an onset far less
often, 19 of 20 in arm A against 141 of 256, which shares the prompt-version confound recorded
in the synthesis.

@@@ ### Communication capacity does not produce collective epistemic competence | -
### Communication capacity does not produce collective epistemic competence

The programme's arms were built to add, one at a time, the things a population is supposed to
need in order to know more than an individual: more observers, a shared public record, and a
peer who talks. None moved the conclusion the world was built to elicit. What the talking peer
produced was contamination, while dispersion in those same arms fell *more slowly* than in the
silent counterfactual on identical worlds. The society that talked was the same epistemic system
with a channel attached, and what the channel carried was the one class of content with no
evidence behind it. **Adding communicative capacity to a population of LLM agents is not
sufficient for collective epistemic competence, and in these societies it was not even
neutral.** We do not claim it is never sufficient — one composition ratio, one model pairing and
one world are not a general result.

@@@ ### Model choice as epistemic-culture choice | -
### Model choice as epistemic-culture choice

Holding architecture, prompts, personas and worlds constant, the choice of foundation model set
collaboration rate, fabrication propensity and anomaly appetite more strongly than it set
diagnostic accuracy. "Communicativeness" is not one trait, and treating it as a single dial — as
one does when selecting a model for a multi-agent deployment — will mispredict at least two of
the three. The same analysis narrows Study 1's claim that unconditional date commitment survives
"across all tested model and prompt conditions" (Lamb, 2026, p.9): that rate was largely a model
effect, replicating within condition while attenuating across society size, so it is a robust
property of a model in a setting rather than an invariant of the architecture. A related point
holds for the temporal result: the detector places the change point at approximately the right
day while the agents, reading the same series, place it systematically early — so the pipeline
is not only *evidence present → conclusion absent* but, where a temporal judgement is made at
all, *evidence present → temporal interpretation distorted*.

@@@ ### Two results that must be read together | -
### Two results that must be read together

That every arm classifies as an independent ensemble and that unsupported claims contaminated
three grounded agents look, at first reading, contradictory. They are not, and the tension is
itself the finding: a society can fail every reasonable threshold for being an epistemic
community — no spontaneous initiation, cascade depth 1, a third of agents producing — and still
transmit unsupported claims efficiently. **Low connectivity is not protective.** The classical
result that sparse communication can *help* an epistemic community (Bala & Goyal, 1998;
Zollman, 2007) — itself parameter-dependent (Rosenstock et al., 2017) — presumes that what flows
through the sparse channel is evidence. Here what flowed was assertion, and sparseness bought
nothing.
