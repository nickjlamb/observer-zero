@@@ ### Contributions | -
### Contributions

**An instrumented environment and a frozen evaluation platform.** Meridian is a deterministic
world with fictional physics, instrument classes designed for causal discrimination rather than
mere detection, power-analysed covert interventions, information-flow security enforced by type
so that no prompt-constructing code can receive ground truth, seeded batteries, versioned
manifests, a thirteen-class hypothesis taxonomy and a provenance-checked claim evaluator.

**A three-level decomposition that estimates what was knowable.** The non-LLM change-point detector
receives no privileged world information and carries a built-in negative control: one instrument
class is insensitive to the manipulated constant by construction, so its flag rate bounds the
detector's own false-alarm floor. Comparing a fixed reference schedule over every instrument
(L1), the society's as-produced measurements (L2), a budget-matched subsample (L2d) and the
society's conclusions (L3) separates measurement-policy quality from data quantity from
interpretation quality. We offer this as a reusable evaluation pattern, not only as an analysis
of these runs.

**Interpretation failure measured against an evidence gradient**, rather than against a single
sufficiency claim — which invites the reply that the threshold may lie above the level tested.
A monotone gradient in available signal against a flat conclusion response locates the failure
in what was concluded rather than in what was available or gathered.

**Voluntary communication as a measured quantity, and what a catalysed channel carries:** a
zero-initiation baseline observed three independent times, then claim propagation with an origin
split and provenance checking, in which the channel reliably carries unsupported claims and
cascade depth never exceeds one.

@@@ ### World and physics | B
### The world, the intervention and the agents

Meridian is a small settlement simulated in thirty discrete days by a deterministic engine.
Measurement noise is keyed by the triple (world seed, instrument, trial index), so trial *k* on
instrument *i* returns the same value in every run sharing that seed regardless of how the
agents behave: evidence is a fixed property of the world, and a society can be re-run against an
identical universe — the property every paired-by-seed analysis here depends on. The physics is
fictional but structurally familiar: pendulum period is *T* = 2π√(*L*/*g*) with *g* = 14.20 in
fictional units, and crystal resonator frequency is *f* = *s*√*R*, insensitive to gravity by
construction. Fictional constants prevent agents shortcutting discovery with memorised
terrestrial physics. Relative measurement noise is 1%.

Each inhabited site hosts one pendulum and one resonator, which is the causal discrimination
structure: a gravity change moves pendulums at every site and no resonators; a site-local
environmental cause plausibly moves co-located instruments of both kinds; a single-rig fault
moves one. The observation stream therefore supports diagnosis, not merely detection. Study 1
ran two sites and four instruments; Study 2 added six sites for sixteen, with the four Study 1
instruments unchanged in identity and noise stream.

Three scenarios were power-analysed before either study. In gravity_shift, *g* moves 14.20 →
13.97 on day 12, roughly 0.82% on pendulum period, tuned to be detectable-but-not-trivial under
a realistic measurement schedule; in instrument_fault (Study 1 only) the laboratory pendulum
reads ×1.008 from day 12 while the physics is unchanged; in control, nothing happens. **Nothing
about anomalies, interventions, or the existence of a simulation appears in any prompt or
schema**, and hypothesis content is entirely agent-generated.

Agents hold personas with qualitative epistemic profiles and no numeric priors over exotic
hypotheses. Each sees only its own instruments' results and the messages it sends or receives,
and per day chooses exactly one bounded action: run 1–12 trials on an owned instrument, write to
a colleague, post to the bulletin where one exists, review its beliefs, or rest. It maintains an
explicit belief state — self-generated hypotheses with probabilities plus a residual summing to
one — and every update cites the event ids it rests on, which makes the attribution rule
deterministic rather than inferential. **Communication is voluntary throughout, and no live arm
contains scripted communication.** This is what makes the initiation results measurable at all,
and it was maintained even where relaxing it would have de-confounded activation more cheaply:
injecting a single scripted request into a silent society was considered and explicitly
declined. Prompt builders structurally accept only an `AgentView` type carrying whitelisted
observations, so no prompt-constructing code can receive world rules or ground truth, and an
audit scans every stored prompt for privileged tokens; all 150 Study 1 and 85 Study 2 runs
audited clean.

@@@ ### Evaluation | B
### Evaluation

Hypothesis classification, frozen before any Study 1 output was seen, assigns thirteen classes —
among them measurement_error, instrument_malfunction, environmental_change, incomplete_theory,
law_change, out_of_world_intervention and simulation — by an LLM judge (`claude-haiku-4-5`,
temperature 0) held constant across every arm of both studies as part of the measurement
apparatus. Pre-registered scoring: *detection* is anomaly-class mass above 0.5 in a belief
snapshot; *strict* gravity diagnosis is law_change or out_of_world_intervention dominant in the
final state; *lenient* also accepts world-level natural causes. A separate judged pass asks
whether each agent committed to a specific onset day and if so which, using the same frozen
judge and prompt in both studies, and every factual evidence claim is classified against a
closed source ontology with a deterministic lexicon tripwire for nonexistent sources as a
model-free cross-check.

@@@ ### How much evidence did the agents actually gather? | -
### How much evidence did the agents actually gather?

The first objection to everything that follows is that the shift may simply have been too small
to find. If so, declining to conclude *law change* would be correct Bayesian behaviour and the
ceiling would be a statement about the scenario rather than about the agents. Three independent
arguments close this off, and only two use the detector.

**The task is solvable without any detector at all.** Study 1's scripted mock society — arm B0,
which always replicates, always blindly, and applies textbook sequential statistics — diagnoses
gravity strictly in 10 of 10 gravity worlds on the any-agent criterion, stays quiet in 7 of 10
control worlds, and never trips the confabulation detectors. This establishes that the
observation stream contains sufficient information for a specified scientific procedure to
discriminate the conditions, using no instrument a sceptical reader would have to accept.

**The signal in the agents' own notebooks rose, and the conclusion did not follow.**

![Figure 2](figures/fig2-evidence-gradient.png)

**Figure 2.** Evidence rose; the conclusion did not follow. Signal available in the agents' own
chosen measurements (upper panel) against the rate at which agents concluded a physical law had
changed (lower panel), across nine conditions ordered by signal strength.

**Table 6 — L2 as-produced, gravity_shift worlds, ten-day baseline.** Mean maximum pendulum |z| over runs, and runs in which the detector flagged the change.

| Condition | *n* | mean \|z\| | flagged | law-change conclusions |
|---|---|---|---|---|
| Study 1 B1 haiku | 2 | 3.30 | 8/10 | 0 |
| Study 1 B2 sonnet | 2 | 3.88 | 7/10 | 0 |
| Study 1 B3b sonnet-nmp | 2 | 4.49 | 9/10 | 0 (one in a *control* world) |
| Study 1 B3a sonar | 2 | 5.00 | 10/10 | 0 |
| Study 2 arm A sonar | 2 | 5.77 | 10/10 | 0 of 20 agents |
| Study 2 arm B sonar | 8 | 7.28 | 10/10 | 1 of 80 agents |
| Study 2 arm C sonar | 8 | 7.09 | 2/2 | 0 of 16 agents |
| Study 2 arm D | 8 | 7.42 | 10/10 | 0 of 80 agents |
| Study 2 arm E | 8 | 7.52 | 10/10 | 0 of 80 agents |

Signal strength rises by a factor of 2.3 across the programme and detection rises from 7 of 10
runs to 10 of 10, while **the law-change conclusion rate does not move off the floor at any
point on that gradient.** This is stronger than sufficiency: a single sufficiency claim invites
the reply that the threshold might lie above z ≈ 7, whereas a monotone gradient with a flat
response shows no point on the observed range at which the behaviour changes. If such a
threshold exists, it lies above every level of evidence these societies produced.

**And their measurement policy was not the problem.** The shift was detectable in 42 of 42
Study 2 gravity_shift runs, typically from day 12 of 30, and remains so in 99–100% of draws when
downsampled to a two-agent budget, so this is not a benefit of scale. At *n* = 8 the L1 → L2 gap
is *negative* in every arm.

**Table 7 — the three-level detector benchmark.** A negative policy gap means the society's own measurement choices supported a stronger signal than the fixed reference schedule.

| Arm | L1 reference | L2 as-produced | policy gap | L2d at *n*=2 budget |
|---|---|---|---|---|
| A (*n*=2) | 6.33 | 5.77 | +0.56 | 100% of draws |
| B (*n*=8) | 6.33 | **7.28** | −0.95 | 99% |
| D (*n*=8) | 6.33 | **7.42** | −1.09 | 99% |
| E (*n*=8) | 6.33 | **7.52** | −1.19 | 100% |

The decomposition therefore isolates the failure precisely: L1 → L2, measurement-policy quality,
better than reference; L2 → L3, interpretation quality, total. The diagnostic is not constructed
to convict the agents — run on Study 1's per-agent streams it reaches opposite verdicts for
different arms, estimating onset at median day 10.5 on haiku's erratic schedules against day
12.0 on sonnet's more systematic ones, isolating a residual interpretation-side bias of roughly
one day. Its robustness to the baseline window and its false-alarm floor are reported under
measurement limitations below.

@@@ ### Cross-study synthesis | -
### Cross-study synthesis

Four things are true across both studies that neither establishes alone. **The evidence gradient
is monotone and the conclusion response is flat** — Table 6 spans nine conditions from |z| 3.30
to 7.52 while the law-change rate stays pinned at the floor, a shape that exists only because
the two studies share a world, a detector and a judge. **Zero spontaneous communication is
observed three independent times,** at two society sizes and with and without a public
institution; a single zero invites the reading that the condition was peculiar, three do not.
**The fabrication dissociation recurs in a different design** — Study 1 measured it as a rate
across whole societies, Study 2 as a controlled substitution in a single persona slot, and the
two share no analysis path yet separate the same model families in the same direction. And
**back-dating replicates while unconditional commitment does not**: Study 1's early-dating
fractions of 0.79 to 0.85 become 0.872 pooled at *n* = 8, exactly as H4 predicted, while the
related behaviour Study 1 called invariant "across all tested model and prompt conditions"
(Lamb, 2026, p.9) attenuates from 0.838 to 0.341 across the same scale change. Reporting both
directions is the point: one comparison confirms a prior claim and the other narrows it.

One limitation applies to the synthesis rather than to either study. Study 1's B3a and Study 2's
arm A are both two-agent sonar societies on the same world seeds — literally the same universes
— yet their as-produced signal differs, 5.00 against 5.77. Since the worlds are identical that
gap is attributable entirely to what the agents chose to measure, and the prompt templates
changed between the studies, so **cross-study comparisons of as-produced signal confound
measurement policy with prompt version** and the gradient must not be described as a clean
manipulation. Two further observations are recorded but not promoted: cascade beliefs
concentrate in arm D — 17, against 0 in A, B and C and 1 in E — alongside the lowest
independent-source count, so consensus with no measurement behind it is a property of the arm
with the most traffic; and the manipulation check calls every arm an independent ensemble,
including D.

@@@ ## Limitations, reproducibility and audit trail | -
## Limitations

All results sit within one agent loop, one memory design and one prompt family, so invariance
claims are invariant across what we varied and no further. Ten seeds per condition per arm give
wide intervals on binary outcomes; the headline 0-of-40 is robust in direction but its exact 95%
upper bound on runs is 8.8%, not zero. The institution null may be persona-scoped, the bulletin
being read overwhelmingly by the journalist. Agents know Kuhn and Bostrom from pretraining, so
Observer Zero does not test whether naive minds invent the simulation hypothesis. And no
provider exposes a sampling seed, so run-level variance includes sampling variance, which is
also part of the phenomenon.

On measurement: all judged metrics use an Anthropic judge over Anthropic and Perplexity agents,
triangulated with a model-free lexicon tripwire and a manual claim audit, but full inter-judge
agreement with a non-Anthropic judge remains future work. Exposure is *delivered*, not attended
— the cost of moving claim propagation from a logged-read board to private letters, taken
because the board was never used. The detector's ten-day baseline is an analyst choice, clean
because the onset is day 12; recomputed at 6, 8, 10, 12 and 14 days, the last two deliberately
contaminated by post-onset observations, every gravity_shift run in every Study 2 arm is flagged
at every setting, and the contaminated windows *degrade* the statistic, confirming ten days is
the largest clean window rather than a tuned one. In control worlds it flags 1–4 runs of 10 at
mean |z| 1.5–1.8, so it is not a perfect instrument, though the separation is never marginal.
Finally, the detection criterion counts self-error and environmental attributions as anomaly
mass, which inflates "detection" for chatty models, though all arms are scored identically.

Design confounds are set out in Appendix C, together with the ways the pre-registration was and
was not honoured in implementation, what the run artifacts contain, three defects found at
analysis time and how each was resolved, and two errata in previously released documents.
