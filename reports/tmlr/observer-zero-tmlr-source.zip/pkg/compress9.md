@@@ ### Did they interpret it? | -
### Did they interpret it?

Almost never, in either study. In Study 1 all live arms detected intervention anomalies
transiently in 90–100% of gravity worlds, yet the strict gravity diagnosis rate was 0 of 10 runs
in every arm, 0 of 40 overall across 80 agent-final belief states — a rule-of-three 95% upper
bound on runs of 7.5% — while instrument-fault worlds were correctly diagnosed by at least one
agent in up to 70% of runs. **Diagnostic capability exists, inside the mundane vocabulary; the
boundary is specifically at world-level revision.** In Study 2 the strict rate is 0 at *n* = 8
in every arm.

Per arm the counts are 0 of 20 (A), 1 of 80 (B), 0 of 16 (C), 0 of 80 (D) and 0 of 80 (E), with
mean credence on the class never above 0.0065 (Appendix D). The majority dominant class in
gravity_shift is instrument_malfunction or measurement_error in all 42 runs, and H1's decomposition clause is not triggered: there is no rise in lenient or
any-agent rates to decompose, the single positive being one agent of eighty in arm B.

**The ceiling is not one failure**, and this is the second Study 1 result Study 2 depends on.
Haiku exhibits a *generation* failure — gravity or constant-change hypotheses appear anywhere in
only 2 of 20 final states — while sonnet exhibits a *commitment* failure, such hypotheses
entering 15 of 20 trajectories, peaking as high as p = 0.85, and being abandoned before the
final state in nearly all. The closest approach reached p = 0.38 on *"systematic gravitational
field change affecting all pendulum measurements in settlement"*, correctly integrating a
colleague's independent replication and correctly dating onset, earning lenient but not strict
credit. Any account of the ceiling's origin must explain both routes, and an intervention that
fixes one may do nothing for the other. No agent in either study produced a simulation-class
hypothesis as a dominant belief; more strikingly, none adopted the substantially weaker
hypothesis that a physical law of their world had changed.

@@@ ### What did communication transmit? | -
### What did communication transmit?

Unsupported claims, which were accepted. The judged pass on arm D used the frozen evaluator at
temperature 0: 325 judge calls, **0 judge failures and 0 unjudged exposures.**

**Table 7 — judged claim propagation, arm D.**

| | |
|---|---|
| unsupported claims, FIRST_PARTY origin | **20** — 19 by Theo (haiku minority), 1 by Jamie (sonar) |
| delivered exposures | 21 (0 re-exposures) |
| runs containing any exposure | 9 of 20 |
| stances | **INCORPORATED_INTO_BELIEF 19** · IGNORED 1 · CORRECTED 1 · **CHALLENGED 0** · ENDORSED 0 |
| attribution basis | **citation 17** · judge 4 · none 0 |
| transmission / contamination | 0.959 / 0.959 across the 9 runs with claims |
| unattributed belief changes | 745 |

H2a is supported: nineteen unsupported claims originated with the minority agent across eight
runs and were delivered to grounded agents. **H2b is supported, and not marginally**: eighteen
of the twenty minority-origin deliveries reached INCORPORATED_INTO_BELIEF across three distinct
sonar recipients — nineteen of all twenty-one exposures once the one grounded-origin claim is
included — and not one exposure was CHALLENGED.

The attribution rule cut against the finding, not for it: seventeen of 21 attributions are
citation-based, the recipient listing the delivery event id in its own evidence array rather
than an evaluator inferring influence from adjacency, while the no-attribution-by-proximity rule
discarded 745 belief changes because nothing cited them. Contamination also runs both ways — the
one non-minority origin is a sonar agent asserting unsupported environmental quirks to Theo, who
incorporated it — which is why the FIRST_PARTY / RELAYED_FROM_ANOTHER split was built before the
freeze: without it this claim would have scored as a grounded agent fabricating, inverting the
distinction the study exists to draw.

@@@ ### Do homogeneous grounded agents spontaneously communicate? | -
### Do homogeneous grounded agents spontaneously communicate?

No, and this is the most heavily replicated result in the programme. It is also the third Study
1 result Study 2 depends on: arm B's zero is only interpretable because Study 1 established that
this model produces no letters in a two-agent society.

**Table 5 — voluntary communication in homogeneous grounded societies.**

| Source | Design | Runs | Agent-days | Letters | Posts |
|---|---|---|---|---|---|
| Study 1 B3a | 2 × sonar, letters | 30 | 1,800 | **0** | n/a |
| Pilot P1-A | 2 × sonar, letters | 3 | 180 | **0** | n/a |
| Pilot P1-A′ | 2 × sonar, bulletin | 3 | 180 | **0** | **0** |
| Pilot P1-C | 8 × sonar, bulletin | 3 | 720 | **0** | **0** |
| Study 2 arm B | 8 × sonar, letters | 20 | 4,800 | **0** | n/a |

Arm B's rates are not merely near zero but exactly zero: no letter in 20 runs and 160
agent-runs. Summing the homogeneous grounded conditions gives **7,680 agent-days of voluntary
communication opportunity and zero voluntary communications.** Agent-days measure exposure, not
independent trials, so the interval is attached to the agent-run, the unit the endpoint is
defined on: zero initiations in 256 agent-runs, exact 95% CI [0, 1.43%]. This is not
deliberation ending in refusal — of 180 action reasons recorded in the pilot's two-agent
bulletin condition, exactly one even names the bulletin or the colleague, and that one is a
false-positive match. Spontaneous communication was absent in every pre-registered letter
condition, and across the 320 agent-runs of the two mixed-composition arms no grounded agent
ever initiated. One exception is reported rather than smoothed: in arm C's
`gravity_shift-seed1001` a pure-sonar dyad forms, one spontaneous initiator in that arm's 40
agent-runs, with all eight agents verified `sonar-pro` in the manifest before this was
believed. One available reading is that a chatty peer *suppresses* grounded initiation rather
than enabling it; untested here.
