@@@ ## Related work | -
## Related work

**Evidence use, and instrumented worlds.** That LLM scientific agents fail to use the evidence
they generate is documented at scale: Ríos-García et al. (2026) evaluate agents across eight
domains in more than 25,000 runs and report evidence non-uptake in 68% of traces, with only 26%
exhibiting refutation-driven belief revision (Bisht et al., 2026). We take this as our starting
point rather than our finding; neither work changes the environment's rules mid-run, computes
the statistical strength of the evidence collected, or separates a failure to detect from a
failure to interpret. Several benchmarks do place agents in worlds whose structure must be
discovered by experiment (Gandhi et al., 2025; Jansen et al., 2024; Wiemann et al., 2026; Zheng
et al., 2026), but all are single-agent and in all of them the world's law is non-canonical
*from the start* — a task-generation device rather than a covert change during the run. The
closest methodological precedent is STOCKTAKE (Deb & Krishnan, 2026), which drives what its
authors call a fair oracle on the identical observation stream the agent receives. The move is
the same as ours; the joint is different. **STOCKTAKE isolates detection → action; we isolate
detection → belief** — ours notice and then conclude wrongly, which is harder to attribute
because no action is available to reveal it. One difference runs in our favour: their oracle
uses the environment's true generative parameters, whereas our detector receives none (Engländer
et al., 2026). On the individual side, belief revision under disconfirming evidence has been
probed mainly through propositional tasks (Jhaveri et al., 2026) and the in-context locking Luo
et al. (2025) identify in ultra-long-horizon tasks — all on verbal evidence, none on noisy
sensor data the agent chose to collect. One thing that literature does *not* support is worth
stating, because our results are liable to be read as supporting it: larger models are *more*
coherent with Bayes' theorem, not less (Imran et al., 2025).

**The voluntary-communication gap.** Generative agent societies have grown from Park et al.'s
(2023) sandbox to million-agent simulators (Yang et al., 2024), but their epistemic object is
almost always opinion or convention — quantities with either no ground truth or a fixed one
(Ashery et al., 2025). The field has developed a substantial self-critique, which we treat as
our framing rather than as an incoming objection: audits against six validity principles find
90.7% of studies violate at least one (Zhou et al., 2025), and generative agent-based modelling
has inherited little of agent-based modelling's validation discipline (Larooij & Törnberg,
2025). Crucially, the field's own communication survey (Yan et al., 2026) describes **no system
in which agents autonomously decide whether to communicate at all**, and where the affordance
exists no take-up or silence rate is reported. This is why our zero baseline is unmeasured
territory rather than merely unreported: in a framework that schedules or requires
communication, the quantity is structurally invisible.

**Contamination and cascades.** That LLM agents adopt peers' claims is well quantified — harmful
revision rising from 15.6% to 62.9% under unanimous wrong peers against beneficial revision from
32.7% to 51.5% under correct ones (Qu et al., 2026), with flip rates of 0.48 to 0.63 elsewhere
(Cho et al., 2025) — but these are dyadic measurements with no network, no persistent belief
state and no provenance. Error propagation along three-agent chains shows *attenuation* rather
than amplification (Jamshidi et al., 2026), which makes "errors amplify through agent chains" an
unsafe premise. The nearest neighbour to our contamination result is CoSim (Lin et al., 2026),
whose misinformation is injected exogenously rather than generated inside the society. Two
cautions against our own reading: some measured conformity may be a prompt artefact requiring no
social speaker at all (Hu & Qu, 2026), and false claims presented as *presupposed* rather than
asserted are accommodated far more readily (Cheng et al., 2026). The classical
network-epistemology results supply the null expectations — informational cascades
(Bikhchandani et al., 1992) and the finding that *less* connected communities can converge on
truth more reliably (Bala & Goyal, 1998; Zollman, 2007), itself not robust across parameter
values (Rosenstock et al., 2017) — but all of them presume that what flows through the channel
is evidence. Appendix E gives this section in full, with the remaining literature.

@@@ ### Data quality | -
### Data quality

All 85 Study 2 runs completed with no re-runs, the stale-final-state rate was zero in every
arm against a pre-registered 10% flag, and the leak audit was clean, so the pre-registered
primary and sensitivity analyses are identical by construction and reported as one.

@@@ ### Implications for deployed multi-agent systems | -
### Implications for deployed multi-agent systems

Three, at the strength of the evidence. Collective competence cannot be inferred from
communication volume: arm D produced the most letters, the most edges, the most cascade beliefs
and the least independent evidential support. The interpretation step should be expected to be
the weak one, so a monitoring system built from such agents would collect adequate evidence of a
regime change and report an instrument fault — and evaluations that score data collection, or
that score conclusions without measuring what evidence was available, will both miss this. And a
quiet channel is not a safe channel: eighteen of twenty unsupported claims were incorporated in
a society that never formed a network at all.

@@@ ## Reproducibility statement | -
## Reproducibility statement

Measurement noise is keyed by the triple (world seed, instrument, trial index), so evidence is a
fixed property of the world and any society can be re-run against an identical universe; every
paired-by-seed analysis depends on this. Prompts, personas, engine constants and model settings
are hashed into a manifest stamped into every run artifact, and the Study 2 design was frozen at
a tagged commit with the world seeds quarantined in code until that freeze. Sampling variance is
not eliminated — no provider exposes a sampling seed at temperature 1.0 — and is treated as part
of measured society variance. The hypothesis judge is a single frozen model at temperature 0,
held constant across every arm of both studies. Derived artifacts sufficient to reproduce every
number reported here, the model code, and the complete raw run artifacts are publicly deposited;
the deposit is withheld from this version to preserve anonymity and will be cited on
de-anonymisation.
