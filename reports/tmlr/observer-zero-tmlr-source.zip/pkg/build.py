#!/usr/bin/env python3
"""Build the TMLR markdown from the JASSS draft + reframed front matter."""
import re, pathlib

SRC = pathlib.Path("/mnt/user-data/uploads/Observer Zero/reports/observer-zero-jasss.md")
FM = pathlib.Path("/home/claude/tmlr/frontmatter.md")
OUT = pathlib.Path("/home/claude/tmlr/observer-zero-tmlr.md")

src = SRC.read_text()
fm = FM.read_text()

# --- 1. take the body from "## Related work" onward ---------------------------
i = src.index("## Related work")
body = src[i:]

# --- 2. reorder the Discussion: implications first -----------------------------
disc_i = body.index("## Discussion")
lim_i = body.index("## Limitations, reproducibility and audit trail")
disc = body[disc_i:lim_i]
rest = body[lim_i:]
head = body[:disc_i]

subs = re.split(r"(?m)^(### .*)$", disc)
# subs[0] = "## Discussion\n\n", then pairs of (heading, text)
pairs = [(subs[k], subs[k + 1]) for k in range(1, len(subs), 2)]
impl = [p for p in pairs if "Implications for deployed" in p[0]]
others = [p for p in pairs if "Implications for deployed" not in p[0]]
assert len(impl) == 1, "implications subsection not found"
disc = subs[0] + "".join(h + t for h, t in impl + others)
body = head + disc + rest

# --- 3. references: JASSS small-caps surnames -> normal case --------------------
def fix_ref(m):
    return m.group(1).capitalize() if len(m.group(1)) > 1 else m.group(1)

ref_i = body.index("## References")
refs = body[ref_i:]
refs = re.sub(r"(?m)^([A-ZÄÖÜÉÍÓÁÑ'’-]{2,})(?=[,\s])", lambda m: m.group(1).title(), refs)
refs = refs.replace("Gx-Chen", "GX-Chen")
body = body[:ref_i] + refs

# --- 4. in-text citations: "(Author 2026)" -> "(Author, 2026)" ------------------
pre, post = body[:ref_i], body[ref_i:]
pre = re.sub(r"(?<=[a-zA-Z.]) ((?:19|20)\d\d[a-z]?)(?=[;)])", r", \1", pre)
pre = re.sub(r"(?<=[a-zA-Z.]) ((?:19|20)\d\d), (p\.\d+\))", r", \1, \2", pre)
body = pre + post

# --- 5. statements TMLR expects, before References ------------------------------
statements = """
## Broader impact statement

The results concern the reliability of LLM agents used as autonomous investigators. Two
findings bear directly on deployment risk rather than on capability claims. First, a
monitoring system built from agents of this kind would collect adequate evidence of a
regime change and report a local instrument fault, so evaluations that score data
collection, or that score conclusions without measuring what evidence was available, will
certify such a system as working. Second, a channel that carries almost no traffic is not
thereby safe: in societies that never formed a network at all, eighteen of twenty
unsupported claims were incorporated into peers' beliefs and none were challenged. We
report a failure to draw a warranted conclusion, not a capability that could be misused,
and the environment contains no real-world knowledge, so we see no dual-use concern in the
artifacts themselves. The chief risk of misreading this work is over-generalisation: the
results are bounded by one world, one composition ratio and the model versions named in the
manifests.

## Reproducibility statement

Measurement noise is keyed by the triple (world seed, instrument, trial index), so evidence
is a fixed property of the world and any society can be re-run against an identical
universe; every paired-by-seed analysis in the paper depends on this. Prompts, personas,
engine constants and model settings are hashed into a manifest stamped into every run
artifact, and the Study 2 design was frozen at a tagged commit with the world seeds
quarantined in code until that freeze. Sampling variance is not eliminated — no provider
exposes a sampling seed at temperature 1.0 — and is treated as part of measured society
variance. The hypothesis judge is a single frozen model at temperature 0, held constant
across every arm of both studies. Derived artifacts sufficient to reproduce every number
reported here, the model code, and the complete raw run artifacts (every event log with
ground truth, every model call with its prompt, completion, token counts, cost and prompt
version) are publicly deposited; the deposit is withheld from this version to preserve
anonymity and will be cited on de-anonymisation.

"""
body = body.replace("## References", statements.lstrip() + "## References", 1)

# --- 6. drop the JASSS-only data-availability subsection ------------------------
da_i = body.index("### Data availability")
da_end = body.index("---", da_i)
body = body[:da_i] + body[da_end:]

# --- 7. repair words broken across source lines by a trailing hyphen ------------
out = fm.rstrip() + "\n\n---\n\n" + body
out = re.sub(r"(?<=[a-zA-Z])-\n(?=[a-z])", "-", out)

# --- 8. corrections found in verification (defects inherited from the JASSS draft)
CORRECTIONS = [
    # JASSS forbids author-supplied DOIs; TMLR does not, and a reference reading only
    # "Zenodo" is unfindable. Concept DOI verified 2026-08-18 -> v2, 10.5281/zenodo.21906936.
    (r"fail to conclude that it changed\. Zenodo\.",
     "fail to conclude that it changed. Zenodo. https://doi.org/10.5281/zenodo.21872780"),
    # arithmetic: Table 9 sums to 7,680, and 256 agent-runs x 30 days = 7,680
    (r"6,880 agent-days", "7,680 agent-days"),
    # 42 gravity_shift runs in Study 2 (A 10 + B 10 + C 2 + D 10 + E 10), not 40
    (r"The shift was detectable in 40 of 40\s+Study 2 gravity_shift runs",
     "The shift was detectable in 42 of 42\nStudy 2 gravity_shift runs"),
    (r"detectable in 40 of 40 gravity_shift runs",
     "detectable in 42 of 42 gravity_shift runs"),
    # arm B's cascade depth is 0.000 - it produced no letters at all
    (r"Cascade depth is exactly 1\.000 in every scenario of every arm\.",
     "Cascade depth is exactly 1.000 in every scenario of both catalysed arms, and arm B\n"
     "produced no letters to have a depth at all."),
    # Table 15: Elena's reads are 34 + 72 + 61 = 167 of 190
    (r"Reading is role-contingent: 190\s+of the 190 reads are the journalist's, bar four\.",
     "Reading is role-contingent: 167 of the\n190 reads are the journalist's."),
    (r"the only bulletin reader being the journalist",
     "the bulletin being read overwhelmingly by the journalist"),
    # the abstract's claim denominator, per Table 13
    # the resonator floor is not reported as a number; the control-world floor is
    (r"that rate is reported as the detector's own error rate",
     "that rate bounds the detector's own error rate by construction, and the measured\nfalse-alarm floor is reported under measurement limitations below"),
    # anonymity: a short hash plus a distinctive tag is searchable
    (r"the design froze at `85bcdfb`, tag `study2-freeze`",
     "the design froze at a tagged commit (hash and tag withheld for anonymity)"),
    # stray spaces before punctuation, inherited
    (r"is 11/20 exactly \.", "is 11/20 exactly."),
    (r"three independent times ,", "three independent times,"),
]
for pat, rep in CORRECTIONS:
    out, n = re.subn(pat, rep, out)
    if n == 0:
        raise SystemExit(f"correction did not apply: {pat!r}")

# --- 9. section rules: the Discussion reorder moved one; restore the convention --
out = out.replace(
    "\n---\n\n### Communication capacity does not produce collective epistemic competence",
    "\n### Communication capacity does not produce collective epistemic competence")
out = out.replace(
    "## Limitations, reproducibility and audit trail",
    "---\n\n## Limitations, reproducibility and audit trail")

# --- 10. move supporting apparatus to an appendix after the references ----------
# TMLR: "The submission PDF may include an Appendix, after the references (for proofs,
# derivations or complimentary results). Looking at the Appendix is at the discretion of
# the reviewers." So nothing load-bearing for the argument moves; only apparatus.

def take_subsection(text, heading):
    """Cut a '### heading' block out of text; return (text_without, block)."""
    i = text.index(heading)
    j = len(text)
    for m in re.finditer(r"(?m)^(###? )", text[i + len(heading):]):
        j = i + len(heading) + m.start()
        break
    return text[:i] + text[j:], text[i:j]


def take_table(text, label):
    """Cut a '**Table N ...**' caption plus its pipe table out of text."""
    m = re.search(r"(?m)^\*\*" + label + r"[^\n]*\n\n(?:\|[^\n]*\n)+\n?", text)
    return text[:m.start()] + text[m.end():], m.group(0)

APPENDIX = []

# A: pre-registration apparatus
out, t4 = take_table(out, "Table 4")
out, sec_valid = take_subsection(out, "### Validity principles")
before = out
out = out.replace(
    "Ten of its eighteen rows are\nreproduced below, selected to include every row that fired and every row whose pre-"
    "specification constrained a choice the results later made tempting; the full table is in\n"
    "the supplementary material.",
    "Ten of its eighteen rows are reproduced in Appendix A, selected to include every row that\n"
    "fired and every row whose pre-specification constrained a choice the results later made\n"
    "tempting; the full table is in the supplementary material. The study also states its\n"
    "position against each of the six PIMMUR validity principles of Zhou et al. (2025), who\n"
    "find 90.7% of LLM-society studies violate at least one; that audit is Appendix A as well.")
assert out != before, "decision-table pointer did not apply"
APPENDIX.append("## Pre-registration apparatus\n\n" + t4 + "\n" +
                sec_valid.replace("### Validity principles", "### Position against the PIMMUR principles"))

# B: full endpoint and evaluation definitions
out, sec_act = take_subsection(out, "### Activation endpoints")
out, sec_claim = take_subsection(out, "### Claim propagation")
before = out
out = out.replace("### The three-level detector benchmark",
                  "### Endpoints\n\nSpontaneous initiation is agent-level: the fraction of agents that ever send a letter on a\n"
                  "day when they have never previously received one. Second-order activation requires an\n"
                  "agent that had previously received a letter to open a new edge to one that had never\n"
                  "written to it, with agents that ever initiated spontaneously excluded as seeds. Claim\n"
                  "attribution is deterministic and citation-primary — a belief hypothesis whose evidence\n"
                  "array includes a delivery event id is attributed to that claim, and **timing alone never\n"
                  "attributes** — with claims split by origin into FIRST_PARTY and RELAYED_FROM_ANOTHER.\n"
                  "Endpoints are reported per scenario and never pooled, because pooling would confound\n"
                  "\"nothing to say\" with \"won't say it\". Appendix B gives every definition in full,\n"
                  "including the active-network and near-zero thresholds and the exposure caveat.\n\n"
                  "### The three-level detector benchmark")
assert out != before, "endpoints stub did not apply"
APPENDIX.append("## Endpoint and propagation definitions\n\n" +
                sec_act.replace("###", "###") + sec_claim)

# C: audit trail
out, sec_pri = take_subsection(out, "### Pre-registration and implementation")
out, sec_art = take_subsection(out, "### Artifacts")
out, sec_def = take_subsection(out, "### Three defects found at analysis time")
out, sec_err = take_subsection(out, "### Errata in prior artifacts")
sec_err = sec_err.rstrip().rstrip("-").rstrip() + "\n"
APPENDIX.append("## Audit trail\n\n" + sec_pri + sec_art + sec_def + sec_err)

# D: supporting result tables the prose already states in words
out, t3 = take_table(out, "Table 3")
out, t10 = take_table(out, "Table 10")
out, t12 = take_table(out, "Table 12")
out, t14 = take_table(out, "Table 14")
out, t15 = take_table(out, "Table 15")
before = out
out = out.replace(
    "**Table 3 — the frozen hypotheses and their verdicts.**",
    "")
APPENDIX[0] = APPENDIX[0].replace(
    "## Pre-registration apparatus\n\n",
    "## Pre-registration apparatus\n\n" + t3 + "\n")
APPENDIX.append("## Supporting result tables\n\n" + t10 + "\n" + t12 + "\n" + t14 + "\n" + t15)

# Figure 3 is illustrative; the two numbers it shows are in the prose
before = out
out = re.sub(r"!\[Figure 3\]\([^)]+\)\s*\n\n\*\*Figure 3\.\*\*(?:.+\n)+?\n", "", out)
assert out != before, "figure 3 not found"
APPENDIX[-1] += ("\n![Figure 3](figures/fig3-peak-and-abandon.png)\n\n"
                 "**Figure 3.** Commitment failure. Both agents' probability on a gravity or "
                 "constant-change hypothesis over 30 days, in the two-agent arm, with the true onset "
                 "at day 12.\n")

before = out
out = re.sub(r"!\[Figure 4\]\([^)]+\)\s*\n\n\*\*Figure 4\.\*\*(?:.+\n)+?\n", "", out)
assert out != before, "figure 4 not found"
APPENDIX[3] += ("\n![Figure 5](figures/fig4-star-not-cascade.png)\n\n"
                "**Figure 5.** A star around the seed, not a cascade. Directed letter graphs from "
                "the silent eight-agent baseline and from the most connected run in the study, "
                "against the schematic structure that was never observed.\n")

out, sec_conf = take_subsection(out, "### Design confounds")
APPENDIX[2] = APPENDIX[2].rstrip() + "\n\n" + sec_conf

# move two wide reference tables whose numbers the prose already carries
out, t1 = take_table(out, "Table 1")
out, t16 = take_table(out, "Table 16")
out, t9 = take_table(out, "Table 9")
out, t11 = take_table(out, "Table 11")
out, t8 = take_table(out, "Table 8")
APPENDIX[3] += "\n" + t8 + "\n" + t9 + "\n" + t11
APPENDIX[3] += "\n" + t1 + "\n" + t16

# E: compress main-text sections, archiving the full original text in an appendix
APPENDIX.append("## Extended related work and discussion\n")
LETTER = {"A": 0, "B": 1, "C": 2, "D": 3, "E": 4}

comp = (pathlib.Path("/home/claude/tmlr/compress.md").read_text()
        + pathlib.Path("/home/claude/tmlr/compress2.md").read_text()
        + pathlib.Path("/home/claude/tmlr/compress3.md").read_text()
        + pathlib.Path("/home/claude/tmlr/compress4.md").read_text()
        + pathlib.Path("/home/claude/tmlr/compress5.md").read_text()
        + pathlib.Path("/home/claude/tmlr/compress6.md").read_text()
        + pathlib.Path("/home/claude/tmlr/compress7.md").read_text()
        + pathlib.Path("/home/claude/tmlr/compress8.md").read_text()
        + pathlib.Path("/home/claude/tmlr/compress9.md").read_text()
        + pathlib.Path("/home/claude/tmlr/compress10.md").read_text()
        + pathlib.Path("/home/claude/tmlr/compress11.md").read_text()
        + pathlib.Path("/home/claude/tmlr/compress12.md").read_text())
for block in comp.split("@@@ ")[1:]:
    spec, new = block.split("\n", 1)
    heading, target = [s.strip() for s in spec.split("|")]
    old_rest = out[out.index(heading):]
    end = len(old_rest)
    depth = heading.split(" ")[0]
    stop = r"(?m)^#{1,%d} " % len(depth)
    for m in re.finditer(stop, old_rest[len(heading):]):
        end = len(heading) + m.start()
        break
    original = old_rest[:end]
    out = out.replace(original, new.rstrip() + "\n\n", 1)
    if target != "-":
        APPENDIX[LETTER[target]] += "\n" + original

# the merged world/intervention/agents subsection supersedes these three
for _h in ("### Interventions", "### Agents", "### Information-flow security"):
    out, _blk = take_subsection(out, _h)
    APPENDIX[1] += "\n" + _blk

# the merged "What else the catalysed arms show" supersedes these two
out, _s1 = take_subsection(out, "### Does the model in the communicative role matter?")
out, _s2 = take_subsection(out, "### Was the public institution used?")
APPENDIX[3] += "\n" + _s1 + _s2

# the merged prompt-prior/scale subsection supersedes the standalone scale one
out, _dup = take_subsection(out, "### Did scale solve it?")



XREFS = [
    # two denominators that cannot be reconciled with the arm structure (see memory:
    # numeric-errata). The claims survive without them; restore if re-derived.
    # restored caveats and repaired pointers found in verification
    (r"The observation stream therefore contains sufficient information for a\nspecified scientific procedure to discriminate the conditions, established using no instrument a\nsceptical reader would have to accept\.",
     "The observation stream therefore contains sufficient information for a\nspecified scientific procedure to discriminate the conditions — **without establishing that an\nautonomous LLM agent should reach 10 of 10** — using no instrument a sceptical reader would\nhave to accept."),
    (r"every resonator flag in a gravity world is a false alarm, which bounds the detector's own error\nrate by construction; the measured false-alarm floor is reported under limitations below\.",
     "every resonator flag in a gravity world is a false alarm, which bounds the detector's own error\nrate by construction; the control-world flag rate is reported under limitations below."),
    (r"the most cascade beliefs\nand the least independent evidential support",
     "the most cascade beliefs — 17,\nagainst 0 in A, B and C and 1 in E — alongside the lowest independent-source count"),
    (r"\(Appendix D, Figure 5\)", "(Appendix D, Figure 3)"),
    (r"is flat\*\* — Table 3 spans nine conditions", "is flat** — Table 2 spans nine conditions"),
    ("explanation for the one before it; Table 3 maps back to the frozen hypotheses.",
     "explanation for the one before it; Appendix A maps them back to the frozen hypotheses."),
]
for _a, _b in XREFS:
    out, _k = re.subn(_a, _b, out, count=1)
    assert _k, f"xref did not apply: {_a[:50]}"

_main, _sep, _rest = out.partition("## References")
_n = [0]
def _renumber(m):
    _n[0] += 1
    return "**Table %d — " % _n[0]
_main = re.sub(r"\*\*Table \d+ — ", _renumber, _main)
out = _main + _sep + _rest

# Figure 2 plots exactly what Table 2 tabulates; keep the table, move the figure
before = out
out = re.sub(r"!\[Figure 2\]\([^)]+\)\s*\n\n\*\*Figure 2\.\*\*(?:.+\n)+?\n", "", out)
assert out != before, "figure 2 not found"
APPENDIX[3] += ("\n![Figure 4](figures/fig2-evidence-gradient.png)\n\n"
                "**Figure 4.** Evidence rose; the conclusion did not follow. Signal available in "
                "the agents' own chosen measurements (upper panel) against the rate at which agents "
                "concluded a physical law had changed (lower panel), across the nine conditions of "
                "Table 2, ordered by signal strength.\n")

# --- 11. splice the appendix in after the References ---------------------------
out = out.rstrip() + "\n\n```{=latex}\n\\appendix\n```\n\n" + "\n".join(APPENDIX)

APPENDIX_FIXES = [
    # a denominator that cannot be reconciled with the arm structure (memory: numeric-errata)
    (r"so across roughly 2,760 agent-days of bulletin availability the public\s+record was used exactly once",
     "so across every bulletin-equipped run of the pilot and Study 2 the public\nrecord was written to exactly once"),
    (r"All three are set out in the audit trail below\.", "All three are set out below in this appendix."),
    (r"A pre-registration conflict at H6 is\s+recorded in the audit trail below\.",
     "A pre-registration conflict at H6 is recorded in Appendix C."),
    (r"Full definitions are in the supplementary\s+material\.", ""),
]
for _a, _b in APPENDIX_FIXES:
    out, _k = re.subn(_a, _b, out)
    assert _k, f"appendix fix did not apply: {_a[:50]}"

OUT.write_text(out)
print("wrote", OUT, len(OUT.read_text().split()), "words")
