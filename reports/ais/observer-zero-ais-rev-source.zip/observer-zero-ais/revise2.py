#!/usr/bin/env python3
"""Second tightening pass — narration only, no caveats touched."""
import re, pathlib

MAIN = pathlib.Path("/home/claude/rev/observer-zero-ais/observer-zero-jaamas.md")
main = MAIN.read_text()

def flex(lit):
    return re.escape(lit).replace(r"\ ", r"\s+").replace(r"\n", r"\s+")

def rep(old, new, tag):
    global main
    pat = re.compile(flex(old))
    main, n = pat.subn(lambda m: new, main)
    assert n == 1, f"{tag}: {n} matches"
    print("ok", tag)

rep("""**Communication is voluntary throughout, and no live arm contains scripted
communication.** This is what makes the initiation results measurable at all, and it was
maintained even where relaxing it would have de-confounded activation more cheaply:
injecting a single scripted request into a silent society was considered and explicitly
declined.""",
"""**Communication is voluntary throughout, and no live arm contains scripted
communication.** This is what makes the initiation results measurable at all; injecting a
single scripted request into a silent society was considered and declined.""", "P2a")

rep("""No, and this is the most heavily replicated result in the programme. It is also the third Study
1 result Study 2 depends on: arm B's zero is only interpretable because Study 1 established that
this model produces no letters in a two-agent society.""",
"""No — the most heavily replicated result in the programme, and the third Study 1 result
Study 2 depends on: arm B's zero is interpretable because Study 1 established that this
model produces no letters in a two-agent society.""", "P2b")

rep("""Depth 1 was not a post-hoc observation:
the pilot correction, issued before the freeze and before any confirmatory spend, recorded that depth was 1 in every pilot run — *"the network densified — more edges, but never
deepened into a chain."* The confirmatory phase tested a stated prediction.""",
"""Depth 1 was not a post-hoc observation: the pilot correction, issued before the freeze, had
recorded depth 1 in every pilot run — *"the network densified — more edges, but never
deepened into a chain"* — so the confirmatory phase tested a stated prediction.""", "P2c")

rep("""The attribution rule cut against the finding, not for it. Seventeen of 21 attributions
are citation-based — the recipient listed the delivery event id in its own evidence array,
the agent stating its source rather than an evaluator inferring influence from adjacency —
while the no-attribution-by-proximity rule discarded 745 belief changes because nothing
cited them. The finding rests on the strongest evidence the design admits.""",
"""The attribution rule cut against the finding, not for it: seventeen of 21 attributions are
citation-based — the recipient listed the delivery event id in its own evidence array — and
the no-attribution-by-proximity rule discarded 745 belief changes nothing cited. The
finding rests on the strongest evidence the design admits.""", "P2d")

rep("""The single post is not a finding but a delivery check — *"I am experiencing what appears
to be a communication system failure and need to verify whether my outbound messages are
being delivered"* — so across every bulletin-equipped run of the pilot and Study 2 the public
record was written to exactly once, by the agent whose private letters were mostly being
ignored, to diagnose a suspected infrastructure fault.""",
"""The single post is a delivery check, not a finding — the agent whose private letters were
mostly being ignored, verifying that its outbound messages were delivered — so across every
bulletin-equipped run of the pilot and Study 2 the public record was written to exactly
once.""", "P2e")

rep("""Holding the asserted answer fixed and deleting the explicit speaker, they find that this no-source condition alone
induces harmful revision in 66.5% of initially correct items across six models and seven
datasets, against 10.3% under a plain re-ask; the strongest expert-panel framing reaches 79.4%,
only 12.9 percentage points above that speaker-free floor.""",
"""Holding the asserted answer fixed and deleting the explicit speaker, they find the
no-source condition alone induces harmful revision in 66.5% of initially correct items,
against 10.3% under a plain re-ask; the strongest expert-panel framing adds only 12.9
percentage points above that speaker-free floor.""", "P2f")

MAIN.write_text(main)
print("words now:", len(main.split()))
