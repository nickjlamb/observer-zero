#!/usr/bin/env python3
"""Apply approved AIS revision changes A1-A6, B1-B6, C1-C9 to the manuscript.
Every replacement asserts exactly one match (flexible whitespace)."""
import re, pathlib

ROOT = pathlib.Path("/home/claude/rev/observer-zero-ais")
MAIN = ROOT / "observer-zero-jaamas.md"
FRONT = ROOT / "frontmatter.md"

main = MAIN.read_text()
front = FRONT.read_text()

def flex(lit):
    return re.escape(lit).replace(r"\ ", r"\s+").replace(r"\n", r"\s+")

applied = []

def rep(text, old, new, tag, count=1):
    pat = re.compile(flex(old))
    text2, n = pat.subn(lambda m: new, text)
    assert n == count, f"{tag}: expected {count} match, got {n}"
    applied.append(tag)
    return text2

def rep_both(old, new, tag):
    """Apply to main (required) and to frontmatter (if present there)."""
    global main, front
    main = rep(main, old, new, tag)
    pat = re.compile(flex(old))
    front2, n = pat.subn(lambda m: new, front)
    if n == 1:
        front = front2
        applied.append(tag + "(front)")

# ============================== A1: abstract ==============================
NEW_ABSTRACT = """An autonomous agent that fails to notice a change in its environment has failed in one of
two ways: it did not collect the evidence the conclusion needs, or it did not draw the
conclusion from evidence it held. Outcome-only evaluation cannot tell the two
apart. We separate them in Meridian, a multi-agent testbed with deterministically seeded
measurement noise, where societies of LLM-based agents choose their own measurements,
maintain explicit probabilistic beliefs, and may communicate at will — no condition
schedules, routes or requires communication — while an environmental law changes covertly
mid-run. A non-LLM sequential change-point detector — blind to the true constants, change
time and shift magnitude — estimates what was knowable from the measurements the agents
chose to take. Across 235 seeded runs in two studies, the second
pre-registered, this localises the failure. The detector finds the change in 42 of 42 confirmatory runs, and
the agents' own measurement choices yield a stronger change signal than a fixed reference
schedule; yet only one of 276 agents concluded the law had changed. Treated as a dependent
variable, communication was absent: 7,680 agent-days of opportunity produced zero voluntary
messages. A catalyst from another model family produced communication but no propagation
beyond directly addressed recipients, while eighteen of its twenty unsupported claims
entered peers' beliefs, none challenged. Evaluations scoring conclusions without measuring
available evidence, or reading communication volume as competence, will miss all three
failures — in the settings, healthcare monitoring and autonomous discovery,
where such agents are proposed."""

wc = len(NEW_ABSTRACT.split())
assert 150 <= wc <= 250, f"abstract word count {wc}"
print("new abstract words:", wc)

for text_name in ("main", "front"):
    t = globals()[text_name]
    m = re.search(r"## Abstract\n\n(.*?)\n\n## Introduction", t, re.S)
    assert m, f"A1: abstract not found in {text_name}"
    globals()[text_name] = t[:m.start(1)] + NEW_ABSTRACT + t[m.end(1):]
applied.append("A1")

# ============================== A2: intro opening ==============================
rep_both(
"""Autonomous agents built on large language models are increasingly proposed as investigators —
debugging systems, analysing experiments, monitoring infrastructure, running scientific
workflows. These settings share a structure familiar from the multi-agent systems literature:""",
"""Autonomous agents built on large language models are increasingly proposed as investigators
in high-stakes settings: monitoring pharmacovigilance and clinical-trial data for safety
signals, running autonomous experiment loops in drug discovery, maintaining infrastructure,
debugging deployed systems. In each, the costly failure is the same — the world changes and
the agent, holding the evidence, does not conclude that it has. These settings share a
structure familiar from the multi-agent systems literature:""", "A2")

# ============================== A3: deployer question ==============================
rep_both(
"""and what the agents concluded from the same stream estimates inference quality, isolated from
acquisition.""",
"""and what the agents concluded from the same stream estimates inference quality, isolated from
acquisition. The question this paper operationalises is the one a deployer must answer before
trusting such a system with a live problem: when it fails, does it fail at sensing or at
reasoning — and would more data help, or not?""", "A3")

# ============================== A4: contributions bullet ==============================
rep_both(
"""versioned manifests, a thirteen-class hypothesis taxonomy and a provenance-checked claim
evaluator.""",
"""versioned manifests, a thirteen-class hypothesis taxonomy and a provenance-checked claim
evaluator — intended as a rehearsal environment in which an agent system can be evaluated
against covert change before it is trusted with a real one.""", "A4")

# ============================== A5: implications paragraph ==============================
rep(main := main,
"""a quiet channel is not a safe channel: eighteen of twenty unsupported claims were
incorporated in a society that never formed a network at all.""",
"""a quiet channel is not a safe channel: eighteen of twenty unsupported claims were
incorporated in a society that never formed a network at all.

Used prospectively, the platform is a pre-deployment evaluation instrument for exactly the
domains that motivated the introduction. Before an agent system is trusted to monitor safety
signals in pharmacovigilance data, to triage anomalies in a clinical-trial stream, or to run
an autonomous discovery loop, it can be run in an instrumented rehearsal world whose ground
truth is known and whose laws change covertly on the experimenter's schedule. The three-level
decomposition then localises any failure to one of three causes with three different
remedies: a measurement policy that under-samples the informative instruments, answered by
better sensing; too little data, answered by a longer horizon; or — the failure found here —
inference that does not convert adequate evidence into the correct belief, which neither
remedy touches. The contamination result adds a fourth pre-deployment check: multi-agent
pipelines in these domains should be assumed to transmit unsupported claims efficiently even
when no functioning communication network has formed.""", "A5")
main = main

# ============================== A6: related work tie ==============================
main = rep(main,
"""What Observer Zero adds is a quantity: how strong the signal was in the agent's own notebook when
it declined to draw the conclusion, and whether that changes as the signal grows.""",
"""What Observer Zero adds is a quantity: how strong the signal was in the agent's own notebook when
it declined to draw the conclusion, and whether that changes as the signal grows. These are
the same investigative workflows — experiment loops, monitoring, discovery — that the
deployment settings in the introduction instantiate.""", "A6")

# ============================== B1: remove indictment ==============================
rep_both(
"""different ways: it did not collect the evidence the conclusion needs, or it did not draw the
conclusion from evidence it had already collected. **Existing evaluations rarely distinguish
the two**, because an evaluation that scores only the outcome — the conclusion reached, the
action taken, the task completed — cannot.""",
"""different ways: it did not collect the evidence the conclusion needs, or it did not draw the
conclusion from evidence it had already collected. An evaluation that scores only the
outcome — the conclusion reached, the action taken, the task completed — cannot distinguish
the two.""", "B1")

# ============================== B2: section title ==============================
main = rep(main, "### Pre-registration and the discipline actually applied",
           "### Design freeze and pre-registration", "B2")

# ============================== B6: freeze opening register ==============================
main = rep(main,
"""and the design froze at `85bcdfb`, tag `study2-freeze`. Design
review was closed by an explicit rule:""",
"""and the design froze at `85bcdfb`, tag `study2-freeze`. To protect the
confirmatory phase from the author's own hindsight, design review was closed by an explicit
rule:""", "B6")

# ============================== C2: freeze prose compress ==============================
main = rep(main,
"""Two consequences cost the study something: an eight-haiku arm was removed despite fitting
the budget, because its inclusion was contingent on a funding fact with no criterion and no decision
date, so it could have been added after D and E were read out; and amendment A4 withdrew a
gloss on cascade reach that would have flipped a pilot run to passing the active-network
bar.""",
"""Two consequences cost the study something: an eight-haiku arm was removed because its
inclusion could have been decided after D and E were read out, and amendment A4 withdrew a
gloss on cascade reach that would have flipped a pilot run to passing the active-network
bar.""", "C2a")

main = rep(main,
"""The test the decision table had to pass was: *for any plausible result, post-results the
author can look here and know exactly how to analyse it.* Ten of its eighteen rows are
reproduced below, selected to include every row that fired and every row whose pre-specification constrained a choice the results later made tempting; the full table is included in the deposited run artifacts.""",
"""The test the decision table had to pass was: *for any plausible result, post-results the
author can look here and know exactly how to analyse it.* Four of its eighteen rows — those
that fired, or bound a choice the results later made tempting — are reproduced below; the
full table is included in the deposited run artifacts.""", "C2b")

# ============================== C1: decision table 10 -> 4 rows ==============================
for row_start in [
    "| B produces 1–2 letters across 20 runs",
    "| A bulletin post appears in C's first 5 runs",
    "| The haiku minority never fabricates",
    "| Fabricated claims spread but are all challenged",
    "| Detector benchmark shows the shift was undetectable in a world",
    "| Bulletin posts in D or E exceed near zero",
]:
    pat = re.compile(re.escape(row_start) + r"[^\n]*\n")
    main, n = pat.subn("", main)
    assert n == 1, f"C1 row: {row_start}"
applied.append("C1")

# ============================== B3/C3: validity principles ==============================
m = re.search(r"### Validity principles\n\n.*?(?=\n### |\n## )", main, re.S)
assert m, "B3: validity section not found"
NEW_VALIDITY = """### Validity principles

The design follows the six validity principles distilled by Zhou et al. [39]:
version-controlled personas with qualitative epistemic profiles and no numeric priors over
exotic hypotheses; genuine unscripted agent-to-agent interaction; persistent belief state
with explicit probabilities and event-id citations; minimal control, communication being
voluntary and itself the dependent variable; unawareness, with no prompt or schema
mentioning anomalies, interventions or simulation and information-flow security enforced by
type; and a grounded deterministic world observed only through instruments.
"""
main = main[:m.start()] + NEW_VALIDITY + main[m.end():]
applied.append("B3/C3")

# ============================== B4: related-work self-critique ==============================
main = rep(main,
"""The field has also developed a substantial
self-critique, which we treat as our framing rather than as an incoming objection: audits against
six validity principles find 90.7% of studies violate at least one, with reported emergent
phenomena often vanishing when the principles are enforced [39], and others argue that generative
agent-based modelling has inherited little of agent-based modelling's validation discipline [19, 21].""",
"""Recent audits of LLM-society studies [39], and calls to import agent-based modelling's
validation discipline [19, 21], motivate the design constraints adopted here.""", "B4")

# ============================== B5: without exception ==============================
main = rep(main,
"""but without exception we
could find it is human↔agent: every benchmark asks whether an agent volunteers something to a
*user*, none whether it volunteers a message to another *agent*.""",
"""but in every benchmark we identified the setting is human↔agent: the question is whether an
agent volunteers something to a *user*, never whether it volunteers a message to another
*agent*.""", "B5")

# ============================== C4: related work cuts ==============================
main = rep(main,
"""One thing this literature does *not* support is worth stating, because our
results are liable to be read as supporting it: larger models are *more* coherent with Bayes'
theorem, not less [14], so the intuition that LLMs are uniformly conservative updaters is not
established.""",
"""One caution: larger models are *more* coherent with Bayes' theorem, not less [14], so the
intuition that LLMs are uniformly conservative updaters is not established.""", "C4a")

main = rep(main,
"""One difference runs in our
favour: their oracle uses the environment's true generative parameters, whereas our detector
receives none [11].""",
"""Their oracle uses the environment's true generative parameters; our detector receives
none [11].""", "C4b")

# fold Network epistemology into Conformity section
m = re.search(r"### Network epistemology\n\n.*?(?=\n---)", main, re.S)
assert m, "C4c: network epistemology section not found"
main = main[:m.start()] + main[m.end():]
NETWORK_FOLD = """ The classical network-epistemology literature supplies the null
expectations — information cascades [4, 5], which humans form in the laboratory including on
the wrong state [1]; complex contagion [7]; and the bounded result that *less* connected
communities can converge on truth more reliably [3, 40], not robust across parameter values
[31], with extensions to propaganda and persistent false belief [27]. Observer Zero's
societies never reach that regime: a cascade requires a chain, and at depth 1.000 there is
none. What we observe is closer to the degenerate case the models assume away: agents who
neither aggregate nor herd, because they do not talk."""
main = rep(main,
"""and false
claims presented as *presupposed* rather than asserted are accommodated far more readily [8], a
pragmatic rather than epistemic candidate for why nothing was challenged.""",
"""and false
claims presented as *presupposed* rather than asserted are accommodated far more readily [8], a
pragmatic rather than epistemic candidate for why nothing was challenged.""" + NETWORK_FOLD, "C4c")

# ============================== C5: evidence section tightening ==============================
main = rep(main,
"""This establishes task solvability — the observation stream contains sufficient information
for a specified scientific procedure to discriminate the conditions — without establishing
that an autonomous LLM agent should reach 10 of 10. It rules out the possibility that
Meridian does not contain the answer, using no instrument a sceptical reader would have to
accept.""",
"""This establishes task solvability — the observation stream contains sufficient information
for a specified scientific procedure to discriminate the conditions — without establishing
that an autonomous LLM agent should reach 10 of 10, and it uses no instrument a sceptical
reader would have to accept.""", "C5a")

main = rep(main,
"""This is stronger than sufficiency: a single sufficiency
claim invites the reply that the threshold might lie above z ≈ 7, whereas a monotone
gradient with a flat response shows no point on the observed range at which the behaviour
changes. If such a threshold exists, it lies above every level of evidence these societies
produced.""",
"""A single sufficiency claim would invite the reply that the threshold lies above z ≈ 7; a
monotone gradient with a flat response forecloses it. If such a threshold exists, it lies
above every level of evidence these societies produced.""", "C5b")

main = rep(main,
"""The diagnostic is not constructed to convict the agents. Run on Study 1's per-agent
streams it reaches opposite verdicts for different arms — estimating onset at median day
10.5 on haiku's, whose erratic schedules genuinely blur it, against day 12.0 on sonnet's
more systematic streams, isolating a residual interpretation-side bias of roughly one day.
The same instrument exonerates one arm and convicts another.""",
"""The diagnostic is not constructed to convict the agents: run on Study 1's per-agent streams
it estimates onset at median day 10.5 on haiku's erratic schedules against day 12.0 on
sonnet's more systematic ones, a residual interpretation-side bias of roughly one day — the
same instrument exonerates one arm and convicts another.""", "C5c")

# ============================== C6: back-dating + model-role tightening ==============================
main = rep(main,
"""Yes, in every arm. This hypothesis was evaluated after the other six — its dating pass was never
run during the confirmatory phase, and was run subsequently with the frozen judge and prompt over
the same artifacts, with the omission, resolution and residual exposure recorded in the audit
trail below.""",
"""Yes, in every arm. This hypothesis was evaluated after the other six, with the frozen judge
and prompt over the same artifacts; the omission, its resolution and the residual exposure
are recorded in the audit trail below.""", "C6a")

main = rep(main,
"""an exact one-sided binomial against a null of 0.5 gives p ≈ 1 × 10⁻²⁰, the more
conservative of the two available tests, since counting early against late alone would
give p ≈ 1 × 10⁻²⁴. Median dating error is negative in every arm, and arm-level detail is
in Table 16.""",
"""an exact one-sided binomial against a null of 0.5 gives p ≈ 1 × 10⁻²⁰, the more
conservative of the two available tests. Median dating error is negative in every arm
(Table 16).""", "C6b")

main = rep(main,
"""The seed behaves identically; the network's response does not. Both minority models
initiate in every single run, and the recruitment gap is dosage rather than eloquence:""",
"""Both minority models initiate in every run, and the recruitment gap is dosage rather than
eloquence:""", "C6c")

main = rep(main,
"""That is an absence rather than a reduced rate, and it refutes the hypothesis that
autonomous scientific reasoning in this architecture *necessarily* produces fabricated
evidence.""",
"""Sonar's zero is an absence, not a reduced rate: autonomous scientific reasoning in this
architecture does not *necessarily* produce fabricated evidence.""", "C6d")

# ============================== C7: synthesis tightening ==============================
main = rep(main,
"""The evidence gradient is monotone and the conclusion response is flat. Table 6 spans
nine conditions from a two-agent haiku society at |z| 3.30 to an eight-agent mixed society
at 7.52 while the law-change rate stays pinned at the floor. No single study produces this
shape; it exists only because the two share a world, a detector and a judge.""",
"""The evidence gradient is monotone and the conclusion response is flat, across nine
conditions from a two-agent haiku society at |z| 3.30 to an eight-agent mixed society at
7.52 (Table 6). The shape exists only because the two studies share a world, a detector and
a judge.""", "C7a")

main = rep(main,
"""Zero spontaneous communication is observed three independent times, at two society
sizes and with and without a public institution. A single zero invites the reading that
the condition was peculiar; three, across a quadrupling of society size and a change of
institution, do not.""",
"""Zero spontaneous communication is observed three independent times, at two society sizes,
with and without a public institution — three zeros across those changes foreclose the
reading that one condition was peculiar.""", "C7b")

# ============================== C8: H4 audit paragraph ==============================
main = rep(main,
"""On H4: the hypothesis, endpoint, judge and prompt were all fixed before any confirmatory
data existed, so the only discretion available was whether to run it at all — which the
pre-registration had already foreclosed, since declining would have been the deviation.
The residual exposure is that the other six results were known when this one was produced;
that cannot influence a deterministic judge executing a frozen prompt, but it is why the
sequence is disclosed.""",
"""On H4: hypothesis, endpoint, judge and prompt were all fixed before any confirmatory data
existed. The residual exposure — the other six results were known when this one was produced
— cannot influence a deterministic judge executing a frozen prompt, but it is why the
sequence is disclosed.""", "C8")

# ============================== C9: figure 1 caption ==============================
rep_both(
"""**Figure 1.** Where collective epistemic competence breaks down: the intended pipeline, and
what Observer Zero finds at each link. The pipeline runs environment → measurement → evidence
→ belief → communication → collective belief, and is intact from environment to evidence,
severed from evidence to belief, largely absent from belief to spontaneous communication,
terminating at depth 1 from communication to network, and — the one place it works
efficiently — open from communication to peer belief, for claims with no evidence behind them.""",
"""**Figure 1.** Where collective epistemic competence breaks down. The pipeline runs
environment → measurement → evidence → belief → communication → collective belief: intact
from environment to evidence, severed from evidence to belief, largely absent from belief to
communication, depth-limited from communication to network, and — the one place it works
efficiently — open from communication to peer belief, for claims with no evidence behind
them.""", "C9")

# ============================== Renumber tables 6-17 -> 5-16 ==============================
assert "Table 5 —" not in main, "Table 5 still present before renumber"
for n in range(6, 18):
    cnt = len(re.findall(rf"Table {n}\b", main))
    assert cnt >= 1, f"Table {n} not found"
    main = re.sub(rf"Table {n}\b", f"Table {n-1}", main)
applied.append("renumber")

MAIN.write_text(main)
FRONT.write_text(front)
print("applied:", len(applied), applied)
print("main words now:", len(main.split()))
