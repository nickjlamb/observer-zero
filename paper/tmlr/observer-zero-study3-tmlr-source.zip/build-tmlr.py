#!/usr/bin/env python3
"""Build the TMLR submission main.tex from the canonical manuscript.

Rerunnable: every substitution asserts on exactly-one match, so a drifted
canonical text fails loudly instead of silently diverging (the programme's
standing pattern). Run from paper/tmlr/:  python3 build-tmlr.py
"""
import re, sys, pathlib

SRC = pathlib.Path("../observer-zero-study3.tex").read_text()

def once(pat, repl, text, flags=0):
    hits = len(re.findall(pat, text, flags))
    assert hits == 1, f"expected 1 match, got {hits}: {pat[:70]}"
    return re.sub(pat, repl, text, count=1, flags=flags)

# ---- body: abstract through \end{document} ---------------------------------
m = re.search(r"\\begin\{abstract\}.*\\end\{document\}", SRC, re.S)
assert m, "body not found"
body = m.group(0)

# ---- structure --------------------------------------------------------------
body = once(r"\\end\{abstract\}\n\n\\vspace\{0\.5em\}\n",
            "\\\\end{abstract}\n\n\\\\section{Introduction}\n", body)
body = body.replace("\\section*{", "\\section{")
body = body.replace("\\subsection*{", "\\subsection{")
# Nature-style abstract has \noindent; harmless, drop it
body = once(r"\\begin\{abstract\}\n\\noindent ", "\\\\begin{abstract}\n", body)

# ---- citations: superscript \cite -> author-year \citep ---------------------
n_cites = body.count("\\cite{")
body = body.replace("\\cite{", " \\citep{")
assert body.count("\\citep{") >= n_cites

# ---- bibliography: thebibliography -> BibTeX, placed after floats -----------
bib = re.search(r"\\clearpage\n\\begin\{thebibliography\}.*?\\end\{thebibliography\}\n", body, re.S)
assert bib, "thebibliography not found"
body = body.replace(bib.group(0), "", 1)
body = once(r"\\end\{table\}\n\n\\end\{document\}",
            "\\\\end{table}\n\n\\\\clearpage\n\\\\bibliographystyle{tmlr}\n\\\\bibliography{references}\n\n\\\\end{document}", body)

# ---- anonymisation ----------------------------------------------------------
body = once(
    r"Observer Zero v1\.1 \(TypeScript; public repository, archived at Zenodo and CoMSES\)",
    "Observer Zero v1.1 (TypeScript; public repository --- link withheld for double-blind review "
    "and provided on de-anonymisation)", body)
body = once(
    re.escape("analysis outputs, freeze document, and run ledger: \\url{https://github.com/nickjlamb/observer-zero} (Zenodo DOI and CoMSES deposit finalised at submission)."),
    "analysis outputs, freeze document, and run ledger are available in a public repository; "
    "the link is withheld to preserve double-blind review and will be provided on "
    "de-anonymisation (Zenodo and CoMSES archival deposits finalised at acceptance).", body)
body = once(r"\\paragraph\{Competing interests\.\} The author declares no competing interests\.\n", "", body)

# ---- Methods -> half-page summary in main + full Methods as Appendix A ------
mm = re.search(r"\\clearpage\n\\section\{Methods\}\n\\small\n(.*?)\n\n\\clearpage\n\\begin\{figure\}", body, re.S)
assert mm, "Methods block not found"
methods_full = mm.group(1)

SUMMARY = r"""\section{Methods summary}

Full Methods are given in Appendix~A; in-text pointers to Methods refer there. In brief: Observer Zero v1.1 implements a deterministic two-site world engine (four instruments, two kinds, byte-reproducible from the world seed; readings rendered at four decimal places, with every agent-visible statistic computed at display resolution), and eleven world types differ only in a registered intervention list --- the treatment world's shared residual stream is supplied by the generator at mix weight 1.0, the control world's by an in-world coupling field at 0.95. A solo scientist agent runs for 40 days, one action per day, under a byte-frozen prompt; belief reviews record explicit hypothesis sets with probabilities. Belief states are scored by a frozen two-stage evaluator (claude-haiku-4-5 at temperature 0; per-item solo classification, three repeats, majority vote; the deprecated version reported beside it on every artifact; a sonnet second judge re-scores a deterministic 20\% sample), calibrated before and after the battery on a human-curated validation set with a designated boundary case. The primary endpoint L1 is summed probability mass above 0.05 on the two external-generation classes. A signed pre-registration freeze (31 August 2026) fixed design, endpoints, strata, seeds, scoring, statistics and interpretation rules before the first confirmatory call, and the committed analysis script ran once; health-gate exclusions and deterministic judge refusals are enumerated per phase in Table~\ref{tab:accounting}. The R39 ablation and the LX-1 licensed extension were separately registered with committed analyzers; post-hoc analyses are labelled as such, including two registered blinded second adjudications.

"""
body = body.replace(mm.group(0), SUMMARY + "\\clearpage\n\\begin{figure}", 1)
body = once(r"\\bibliography\{references\}\n",
            "\\\\bibliography{references}\n\n\\\\appendix\n\\\\section{Methods}\n\\\\small\n" + methods_full.replace("\\", "\\\\") + "\n", body)

# ---- assemble ---------------------------------------------------------------
PREAMBLE = r"""\documentclass[10pt]{article} % TMLR submission build (generated by build-tmlr.py)
\usepackage{tmlr}
% Camera-ready: \usepackage[accepted]{tmlr}   Preprint: \usepackage[preprint]{tmlr}
\usepackage[utf8]{inputenc}
\usepackage[T1]{fontenc}
\usepackage{microtype}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage{array}
\usepackage[hidelinks]{hyperref}
\usepackage{url}
\usepackage{caption}
\captionsetup{font=small,labelfont=bf,width=.95\textwidth}

\title{Language model agents describe anomalous evidence without forming the hypothesis that explains it}

% Hidden automatically while the tmlr package runs in submission mode;
% non-anonymous submissions are rejected without review.
\author{\name Nick Lamb \email nick@pharmatools.ai \\
      \addr PharmaTools.AI, Oxford, United Kingdom}

\def\month{MM}
\def\year{YYYY}
\def\openreview{\url{https://openreview.net/forum?id=XXXX}}

\begin{document}

\maketitle

"""
out = PREAMBLE + body + "\n"

# ---- anonymity sweep on the OUTPUT (source level) ---------------------------
# the \author block is the single permitted occurrence of each identity token
visible = out.replace("\\author{\\name Nick Lamb \\email nick@pharmatools.ai \\\\\n      \\addr PharmaTools.AI, Oxford, United Kingdom}", "")
for tok in ["Lamb", "nickjlamb", "PharmaTools", "pharmatools", "0009-0009", "github.com", "zenodo.org", "10.5281"]:
    assert tok not in visible, f"identity token leaked outside author block: {tok}"

pathlib.Path("main.tex").write_text(out)
print(f"wrote main.tex ({len(out)} bytes); citations converted: {n_cites}")
